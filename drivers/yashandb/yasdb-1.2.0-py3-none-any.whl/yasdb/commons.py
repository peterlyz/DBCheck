import ctypes
import datetime
import logging
import sys
from enum import Enum

from yasdb.libs import yacli
from yasdb.libs.exceptions import YasdbErr

YASDB_LAST_ERR: YasdbErr = YasdbErr()
STR_CODE_TYPE: str = "UTF-8"
MOUTH_PER_DAY: float = 30.4368499
LOB_BUFFER_SIZE: int = 256
MAX_VARCHAR_LENGTH: int = 32000
HIGHLIGHT_OUTPUT_PREFIX = "\033[1;37;41m"
HIGHLIGHT_OUTPUT_SUFFIX = "\033[0m"

logging.basicConfig(format="%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s", level=logging.WARNING)

# for compatible with django-orm
def Binary(value):
    return value

class YasdbState(Enum):
    INIT = 0
    OPEN = 1
    CLOSED = 2


class YacUtil:
    @staticmethod
    def align_size(size: int) -> int:
        margin = size % 4
        return size + (4 - margin) if margin != 0 else size

    @staticmethod
    def assert_ret(ret: yacli.YacResult):
        if ret == yacli.YAC_SUCCESS:
            return
        ex = YASDB_LAST_ERR.assert_last_error()
        if ex is not None:
            raise ex

    @staticmethod
    def alloc_yac_bool(value=None):
        t = yacli.YacBool
        return ctypes.POINTER(t)(t(False) if value is None else t(value))

    @staticmethod
    def is_overflow(value):
        return value > sys.maxsize or value < -sys.maxsize - 1

    @staticmethod
    def alloc_yac_int8(value=None):
        t = yacli.YacInt8
        return ctypes.POINTER(t)(t(0) if value is None else t(value))

    @staticmethod
    def alloc_yac_int16(value=None):
        t = yacli.YacInt16
        return ctypes.POINTER(t)(t(0) if value is None else t(value))

    @staticmethod
    def alloc_yac_int32(value=None):
        t = yacli.YacInt32
        return ctypes.POINTER(t)(t(0) if value is None else t(value))

    @staticmethod
    def alloc_yac_int64(value=None):
        t = yacli.YacInt64
        return ctypes.POINTER(t)(t(0) if value is None else t(value))

    @staticmethod
    def alloc_yac_uint8(value=None):
        t = yacli.YacUint8
        return ctypes.POINTER(t)(t(0) if value is None else t(value))

    @staticmethod
    def alloc_yac_uint16(value=None):
        t = yacli.YacUint16
        return ctypes.POINTER(t)(t(0) if value is None else t(value))

    @staticmethod
    def alloc_yac_uint32(value=None):
        t = yacli.YacUint32
        return ctypes.POINTER(t)(t(0) if value is None else t(value))

    @staticmethod
    def alloc_yac_uint64(value=None):
        t = yacli.YacUint64
        return ctypes.POINTER(t)(t(0) if value is None else t(value))

    @staticmethod
    def alloc_yac_float(value=None):
        t = yacli.YacFloat
        return ctypes.POINTER(t)(t(0.0) if value is None else t(value))

    @staticmethod
    def alloc_yac_double(value=None):
        t = yacli.YacDouble
        return ctypes.POINTER(t)(t(0.0) if value is None else t(value))

    @staticmethod
    def alloc_yac_number(value=None):
        t = yacli.YacNumber
        return ctypes.POINTER(t)(t(0.0) if value is None else t(value))

    @staticmethod
    def alloc_yac_date(value=None):
        t = yacli.YacDate
        return ctypes.POINTER(t)(t() if value is None else t(value))

    @staticmethod
    def alloc_yac_shorttime(value=None):
        t = yacli.YacShortTime
        return ctypes.POINTER(t)(t() if value is None else t(value))

    @staticmethod
    def alloc_yac_timestamp():
        t = yacli.YacTimestamp
        return ctypes.POINTER(t)(t())

    @staticmethod
    def alloc_yac_yminterval(value=None):
        t = yacli.YacYMInterval
        return ctypes.POINTER(t)(t() if value is None else t(value))

    @staticmethod
    def alloc_yac_dsinterval(value=None):
        t = yacli.YacDSInterval
        return ctypes.POINTER(t)(t() if value is None else t(value))

    @staticmethod
    def alloc_yac_char(value):  # value is size or stringdata
        _v = value
        if isinstance(value, str):
            _v = value.encode(STR_CODE_TYPE)
        return ctypes.POINTER(yacli.YacChar)(ctypes.create_string_buffer(_v))

    @staticmethod
    def alloc_yac_binary(value):
        if isinstance(value, bytes):
            ArrayType = yacli.YacUint8 * len(value)
            return ctypes.cast(value, ctypes.POINTER(ArrayType))
        elif isinstance(value, int):
            ArrayType = yacli.YacUint8 * value
            return ctypes.POINTER(ArrayType)(ArrayType())

    @staticmethod
    def ptr_value_size(ptr):
        if isinstance(ptr.contents, yacli.YacChar):
            return len(ctypes.string_at(ptr))
        return ctypes.sizeof(ptr.contents)

    @staticmethod
    def alloc_yac_loblocator(value=None):
        t = yacli.YacLobLocator
        return ctypes.POINTER(t)(t() if value is None else t(value))

    @staticmethod
    def pointer_value(ptr):
        if ptr is None:
            return None
        if isinstance(ptr.contents, yacli.YacChar):
            return ctypes.string_at(ptr).decode(STR_CODE_TYPE)
        return ptr.contents.value

    @staticmethod
    def pointer_bytes(ptr, size):
        return ctypes.string_at(ptr, size=size)

    @staticmethod
    def from_yac_timestamp(ts: yacli.YacTimestamp) -> datetime.datetime:
        year_ptr = YacUtil.alloc_yac_int16()
        mon_ptr = YacUtil.alloc_yac_uint8()
        day_ptr = YacUtil.alloc_yac_uint8()
        hour_ptr = YacUtil.alloc_yac_uint8()
        min_ptr = YacUtil.alloc_yac_uint8()
        sec_ptr = YacUtil.alloc_yac_uint8()
        msc_prt = YacUtil.alloc_yac_uint32()

        ret = yacli.yacTimestampGetTimestamp(
            ts, year_ptr, mon_ptr, day_ptr, hour_ptr, min_ptr, sec_ptr, msc_prt
        )
        YacUtil.assert_ret(ret)
        return datetime.datetime(
            year=YacUtil.pointer_value(year_ptr),
            month=YacUtil.pointer_value(mon_ptr),
            day=YacUtil.pointer_value(day_ptr),
            hour=YacUtil.pointer_value(hour_ptr),
            minute=YacUtil.pointer_value(min_ptr),
            second=YacUtil.pointer_value(sec_ptr),
            microsecond=YacUtil.pointer_value(msc_prt),
        )

    @staticmethod
    def to_yac_timestamp(dt: datetime.datetime):
        year_ptr = yacli.YacInt16(dt.year)
        mon_ptr = yacli.YacUint8(dt.month)
        day_ptr = yacli.YacUint8(dt.day)
        hour_ptr = yacli.YacUint8(dt.hour)
        min_ptr = yacli.YacUint8(dt.minute)
        sec_ptr = yacli.YacUint8(dt.second)
        msc_prt = yacli.YacUint32(dt.microsecond)
        ts = YacUtil.alloc_yac_timestamp()

        ret = yacli.yacTimestampSetTimestamp(
            ts, year_ptr, mon_ptr, day_ptr, hour_ptr, min_ptr, sec_ptr, msc_prt
        )
        YacUtil.assert_ret(ret)
        return ts

    @staticmethod
    def from_yac_date(yac_date: yacli.YacDate) -> datetime.date:
        year_ptr = YacUtil.alloc_yac_int16()
        mon_ptr = YacUtil.alloc_yac_uint8()
        day_ptr = YacUtil.alloc_yac_uint8()
        ret = yacli.yacDateGetDate(yac_date, year_ptr, mon_ptr, day_ptr)
        YacUtil.assert_ret(ret)
        return datetime.date(
            year=YacUtil.pointer_value(year_ptr),
            month=YacUtil.pointer_value(mon_ptr),
            day=YacUtil.pointer_value(day_ptr),
        )

    @staticmethod
    def to_yac_date(dt: datetime.date):
        year_ptr = yacli.YacInt16(dt.year)
        mon_ptr = yacli.YacUint8(dt.month)
        day_ptr = yacli.YacUint8(dt.day)
        yac_date = YacUtil.alloc_yac_date()
        ret = yacli.yacDateSetDate(yac_date, year_ptr, mon_ptr, day_ptr)
        YacUtil.assert_ret(ret)
        return yac_date

    @staticmethod
    def from_yac_shorttime(ts: yacli.YacShortTime) -> datetime.time:
        hour_ptr = YacUtil.alloc_yac_uint8()
        min_ptr = YacUtil.alloc_yac_uint8()
        sec_ptr = YacUtil.alloc_yac_uint8()
        msc_prt = YacUtil.alloc_yac_uint32()

        ret = yacli.yacShortTimeGetShortTime(ts, hour_ptr, min_ptr, sec_ptr, msc_prt)
        YacUtil.assert_ret(ret)
        return datetime.time(
            hour=YacUtil.pointer_value(hour_ptr),
            minute=YacUtil.pointer_value(min_ptr),
            second=YacUtil.pointer_value(sec_ptr),
            microsecond=YacUtil.pointer_value(msc_prt),
        )

    @staticmethod
    def to_yac_shorttime(dt: datetime.time):
        hour_ptr = yacli.YacUint8(dt.hour)
        min_ptr = yacli.YacUint8(dt.minute)
        sec_ptr = yacli.YacUint8(dt.second)
        msc_prt = yacli.YacUint32(dt.microsecond)
        ts = YacUtil.alloc_yac_shorttime()
        ret = yacli.yacShortTimeSetShortTime(ts, hour_ptr, min_ptr, sec_ptr, msc_prt)
        YacUtil.assert_ret(ret)
        return ts

    @staticmethod
    def from_yac_ym_interval(yac_ym: yacli.YacYMInterval) -> datetime.timedelta:
        year_ptr = YacUtil.alloc_yac_int32()
        mon_ptr = YacUtil.alloc_yac_int32()
        ret = yacli.yacYMIntervalGetYearMonth(yac_ym, year_ptr, mon_ptr)
        YacUtil.assert_ret(ret)
        year = YacUtil.pointer_value(year_ptr)
        month = YacUtil.pointer_value(mon_ptr)

        days = (year * 12 + month) * MOUTH_PER_DAY
        return datetime.timedelta(days=days)

    @staticmethod
    def from_yac_ds_interval(yac_ds: yacli.YacDSInterval) -> datetime.timedelta:
        day_ptr = YacUtil.alloc_yac_int32()
        hour_ptr = YacUtil.alloc_yac_int32()
        min_ptr = YacUtil.alloc_yac_int32()
        sec_ptr = YacUtil.alloc_yac_int32()
        msc_prt = YacUtil.alloc_yac_int32()

        ret = yacli.yacDSIntervalGetDaySecond(
            yac_ds, day_ptr, hour_ptr, min_ptr, sec_ptr, msc_prt
        )
        YacUtil.assert_ret(ret)
        sign = 1 if YacUtil.pointer_value(day_ptr) >= 0 else -1
        return sign * datetime.timedelta(
            days=YacUtil.pointer_value(day_ptr) * sign,
            hours=YacUtil.pointer_value(hour_ptr),
            minutes=YacUtil.pointer_value(min_ptr),
            seconds=YacUtil.pointer_value(sec_ptr),
            microseconds=YacUtil.pointer_value(msc_prt),
        )

    @staticmethod
    def to_yac_ds_interval(td: datetime.timedelta):
        # deal with python negative timedelta format
        if td.days < 0:
            total_microseconds = -((td.days * 86400 + td.seconds) * 1000000 + td.microseconds)
            sec, microsecond = int(total_microseconds / 1000000), (total_microseconds % 1000000)
            minute, sec = int(sec / 60), (sec % 60)
            hour, minute = int(minute / 60), (minute % 60)
            day, hour = int(hour / 24), (hour % 24)
            day, hour, minute, sec, microsecond = -day, -hour, -minute, -sec, -microsecond
        else:
            day = td.days
            minute, sec = int(td.seconds / 60), td.seconds % 60
            hour, minute = int(minute / 60), minute % 60
            microsecond = td.microseconds

        day_ptr = yacli.YacInt32(day)
        hour_ptr = yacli.YacInt32(hour)
        min_ptr = yacli.YacInt32(minute)
        sec_ptr = yacli.YacInt32(sec)
        msc_prt = yacli.YacInt32(microsecond)

        yac_dt = YacUtil.alloc_yac_dsinterval()

        ret = yacli.yacDSIntervalSetDaySecond(
            yac_dt, day_ptr, hour_ptr, min_ptr, sec_ptr, msc_prt
        )
        YacUtil.assert_ret(ret)
        return yac_dt
