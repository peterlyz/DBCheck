import sys
import datetime
import decimal
import json
from ctypes import POINTER

from yasdb.libs import yacli, exceptions
from yasdb.commons import YacUtil, STR_CODE_TYPE
from yasdb.lob import LobValue


class YasType:
    __slots__ = ("_bind_ptr", "_bind_size", "_bind_type", "_value", "_lob")
    typ = yacli.YAC_TYPE_UNKNOWN
    typename = "UNKNOW"
    default_size = -1
    _ptr_func = None

    @property
    def bind_ptr(self):
        return self._bind_ptr

    @property
    def bind_size(self):
        return self._bind_size

    @property
    def bind_type(self):
        return self._bind_type

    def __init__(self, value=None) -> None:
        self._bind_ptr: POINTER = None
        self._bind_size: int = 0
        self._bind_type: yacli.YacType = 0
        self._value = None

        if value is None:
            return
        self._value = value
        self.set_value(value)

    def get_value(self):
        if self._value:
            return self._value
        if not self._bind_ptr:
            return None
        return YacUtil.pointer_value(self._bind_ptr)

    def set_value(self, value=None, size=None):
        self._bind_type = self.typ
        self._bind_ptr = self.__class__._ptr_func(value=value)
        self._bind_size = self.default_size if size is None else size

    def is_lob(self):
        return self.typ in (
            yacli.YAC_TYPE_BLOB,
            yacli.YAC_TYPE_CLOB,
            yacli.YAC_TYPE_NCLOB,
        )

    def is_char(self):
        return self.typename in (
            "CHAR",
            "VARCHAR",
        )

    def is_nchar(self):
        return self.typename in (
            "NCHAR",
            "NVARCHAR",
        )

    def get_desc_size(self, desc):
        return desc.size


class BOOL(YasType):
    typ, typename, default_size, _ptr_func = (
        yacli.YAC_TYPE_BOOL,
        "BOOL",
        1,
        YacUtil.alloc_yac_bool,
    )


class BYTE(YasType):
    typ, typename, default_size, _ptr_func = (
        yacli.YAC_TYPE_TINYINT,
        "TINYINT",
        1,
        YacUtil.alloc_yac_int8,
    )


class SHORT(YasType):
    typ, typename, default_size, _ptr_func = (
        yacli.YAC_TYPE_SMALLINT,
        "SMALLINT",
        2,
        YacUtil.alloc_yac_int16,
    )


class INTEGER(YasType):
    typ, typename, default_size, _ptr_func = (
        yacli.YAC_TYPE_INTEGER,
        "INTEGER",
        4,
        YacUtil.alloc_yac_int32,
    )


class BIGINT(YasType):
    typ, typename, default_size, _ptr_func = (
        yacli.YAC_TYPE_BIGINT,
        "BIGINT",
        8,
        YacUtil.alloc_yac_int64,
    )

    def set_value(self, value=None, size=None):
        if value is not None and YacUtil.is_overflow(value):
            raise OverflowError("bind int value is overflow")
        return super().set_value(value=value, size=size)


class FLOAT(YasType):
    typ, typename, default_size, _ptr_func = (
        yacli.YAC_TYPE_FLOAT,
        "FLOAT",
        4,
        YacUtil.alloc_yac_float,
    )


class DOUBLE(YasType):
    typ, typename, default_size, _ptr_func = (
        yacli.YAC_TYPE_DOUBLE,
        "DOUBLE",
        8,
        YacUtil.alloc_yac_double,
    )


class NUMBER(YasType):
    typ, typename, default_size, _ptr_func = yacli.YAC_TYPE_NUMBER, "NUMBER", 40, None

    def get_value(self):
        data = super().get_value()
        if data is None:
            return None
        return decimal.Decimal(data)

    def set_value(self, value=None, size=None):
        self._bind_type = yacli.YAC_TYPE_VARCHAR
        if value is not None:
            if isinstance(value, decimal.Decimal):
                self._bind_ptr = YacUtil.alloc_yac_char(value=value.to_eng_string())
            elif isinstance(value, str):
                self._bind_ptr = YacUtil.alloc_yac_char(value=value)
            else:
                raise exceptions.OperationalError(
                    "number type value must be decimal.Decimal or str"
                )
            self._bind_size = YacUtil.ptr_value_size(self._bind_ptr) + 1
        else:
            self._bind_ptr = YacUtil.alloc_yac_char(value=self.default_size)
            self._bind_size = self.default_size


class DATE(YasType):
    typ, typename, default_size = yacli.YAC_TYPE_DATE, "DATE", 8
    _ptr_func, _to_func, _from_func = (
        YacUtil.alloc_yac_date,
        YacUtil.to_yac_date,
        YacUtil.from_yac_date,
    )

    def get_value(self):
        if self._bind_ptr is None:
            return None
        return self.__class__._from_func(self._bind_ptr.contents)

    def set_value(self, value=None, size=None):
        if value is None and self.__class__._to_func is None:
            raise exceptions.OperationalError(
                "{} value is required".format(self.typename)
            )
        self._bind_type = self.typ
        self._bind_ptr = (
            self.__class__._ptr_func()
            if value is None
            else self.__class__._to_func(value)
        )
        self._bind_size = self.default_size if size is None else size


class TIME(DATE):
    typ, typename, default_size = yacli.YAC_TYPE_SHORTTIME, "SHORTTIME", 8
    _ptr_func, _to_func, _from_func = (
        YacUtil.alloc_yac_shorttime,
        YacUtil.to_yac_shorttime,
        YacUtil.from_yac_shorttime,
    )


class DATETIME(DATE):
    typ, typename, default_size = yacli.YAC_TYPE_TIMESTAMP, "TIMESTAMP", 8
    _ptr_func, _to_func, _from_func = (
        YacUtil.alloc_yac_timestamp,
        YacUtil.to_yac_timestamp,
        YacUtil.from_yac_timestamp,
    )


class TIMEDELTA(DATE):
    typ, typename, default_size = yacli.YAC_TYPE_DS_INTERVAL, "DS_INTERVAL", 8
    _ptr_func, _to_func, _from_func = (
        YacUtil.alloc_yac_dsinterval,
        YacUtil.to_yac_ds_interval,
        YacUtil.from_yac_ds_interval,
    )


class CHAR(YasType):
    typ, typename, default_size = yacli.YAC_TYPE_CHAR, "CHAR", 8000

    def set_value(self, value=None, size=None):
        if value is not None and not isinstance(value, str):
            raise exceptions.OperationalError("string type value must be str")
        self._bind_type = self.typ
        if value is not None:
            self._bind_ptr = YacUtil.alloc_yac_char(value=value)
            self._bind_size = YacUtil.ptr_value_size(self._bind_ptr) + 1
        else:
            self._bind_ptr = YacUtil.alloc_yac_char(value=size)
            self._bind_size = size

    def get_desc_size(self, desc, ratio=1):
        return desc.size * ratio + 1


class VARCHAR(CHAR):
    typ, typename = yacli.YAC_TYPE_VARCHAR, "VARCHAR"


class NCHAR(CHAR):
    typ, typename = yacli.YAC_TYPE_VARCHAR, "NCHAR"


class NVARCHAR(CHAR):
    typ, typename = yacli.YAC_TYPE_VARCHAR, "NVARCHAR"


class BINARY(YasType):
    typ, typename, default_size = yacli.YAC_TYPE_BINARY, "BINARY", 8000

    def set_value(self, value=None, size=None):
        if value is not None and not isinstance(value, bytes):
            raise exceptions.OperationalError("binary type value must be bytes")
        self._bind_type = self.typ
        if value is not None:
            self._bind_ptr = YacUtil.alloc_yac_binary(value=value)
            self._bind_size = YacUtil.ptr_value_size(self._bind_ptr)
        else:
            self._bind_ptr = YacUtil.alloc_yac_binary(value=size)
            self._bind_size = size

    def get_value(self, size):
        return YacUtil.pointer_bytes(self._bind_ptr, size)

    def get_desc_size(self, desc):
        return YacUtil.align_size(desc.display_size)


class BIT(BIGINT):
    typ, typename = yacli.YAC_TYPE_BIT, "BIT"

    def set_value(self, value=None, size=None):
        super().set_value(value=value, size=size)
        self._bind_type = yacli.YAC_TYPE_BIGINT

    def get_value(self, size):
        data = YacUtil.pointer_bytes(self._bind_ptr, size)
        return format(int.from_bytes(data, byteorder="little"), "b")


class ROWID(CHAR):
    typ, typename, default_size = yacli.YAC_TYPE_ROWID, "ROWID", 44

    def set_value(self, value=None, size=None):
        if size is None:
            raise exceptions.OperationalError("rowid type: size must be given")
        self._bind_size = size
        self._bind_ptr = YacUtil.alloc_yac_char(size)
        self._bind_type = yacli.YAC_TYPE_VARCHAR

    def get_desc_size(self, desc):
        return desc.display_size


class JSON(CHAR):
    typ, typename, default_size = yacli.YAC_TYPE_JSON, "JSON", 32000

    def set_value(self, value=None, size=None):
        self._bind_type = yacli.YAC_TYPE_VARCHAR
        if value is None and size is None:
            raise exceptions.OperationalError("json type: value or size must be given")
        if isinstance(value, str):
            self._bind_ptr = YacUtil.alloc_yac_char(value=value)
            self._bind_size = YacUtil.ptr_value_size(self._bind_ptr) + 1
        elif isinstance(value, (list, dict)):
            data = json.dumps(value)
            self._bind_ptr = YacUtil.alloc_yac_char(value=data)
            self._bind_size = YacUtil.ptr_value_size(self._bind_ptr) + 1
        else:
            self._bind_ptr = YacUtil.alloc_yac_char(value=size)
            self._bind_size = size

    def get_value(self):
        data = YacUtil.pointer_value(self._bind_ptr)
        if data is None:
            return None
        return json.loads(data)


class NONE(CHAR):
    typ, typename = yacli.YAC_TYPE_UNKNOWN, "NONE"

    def __init__(self) -> None:
        super().__init__()

    def set_value(self, value=None, size=None):
        self._bind_type = yacli.YAC_TYPE_VARCHAR
        self._bind_ptr = YacUtil.alloc_yac_char("")
        self._bind_size = 1


class YEARDELTA(CHAR):
    typ, typename, default_size = yacli.YAC_TYPE_YM_INTERVAL, "YM_INTERVAL", 128

    def set_value(self, value=None, size=None):
        super().set_value(value, size)
        self._bind_type = yacli.YAC_TYPE_VARCHAR

    def get_desc_size(self, desc):
        return desc.display_size


class BLOB(YasType):
    typ, typename = yacli.YAC_TYPE_BLOB, "BLOB"

    def __init__(self) -> None:
        self._lob = None
        super().__init__()

    def set_value(self, value=None, conn=None, is_tmp=True, free_with_conn=False):
        self._bind_type = self.typ
        self._lob = LobValue(
            conn, self._bind_type, is_tmp=is_tmp, free_with_conn=free_with_conn
        )
        self._bind_ptr = self._lob.locator_ptr
        self._bind_size = -1
        if value is None:
            return
        data = bytes(value, encoding=STR_CODE_TYPE) if isinstance(value, str) else value
        self._lob.write(data)

    def get_value(self) -> bytes:
        if not self._lob:
            return None
        return self._lob.read()

    def free(self):
        if not self._lob:
            return None
        self._lob.free()


class CLOB(BLOB):
    typ, typename = yacli.YAC_TYPE_CLOB, "CLOB"

    def get_value(self):
        data = super().get_value()
        if data is None:
            return None
        return data.decode()


class NCLOB(CLOB):
    typ, typename = yacli.YAC_TYPE_NCLOB, "NCLOB"


TYPE_TO_YAS = {
    bool: BOOL,
    int: BIGINT,
    float: DOUBLE,
    str: VARCHAR,
    bytes: BINARY,
    type(None): NONE,
    datetime.datetime: DATETIME,
    datetime.date: DATE,
    datetime.timedelta: TIMEDELTA,
    datetime.time: TIME,
    decimal.Decimal: NUMBER,
    list: JSON,
    dict: JSON,
}

YAS_INDEXS = {
    yacli.YAC_TYPE_UNKNOWN: NONE,
    yacli.YAC_TYPE_BOOL: BOOL,
    yacli.YAC_TYPE_TINYINT: BYTE,
    yacli.YAC_TYPE_SMALLINT: SHORT,
    yacli.YAC_TYPE_INTEGER: INTEGER,
    yacli.YAC_TYPE_BIGINT: BIGINT,
    yacli.YAC_TYPE_FLOAT: FLOAT,
    yacli.YAC_TYPE_DOUBLE: DOUBLE,
    yacli.YAC_TYPE_NUMBER: NUMBER,
    yacli.YAC_TYPE_DATE: DATE,
    yacli.YAC_TYPE_SHORTTIME: TIME,
    yacli.YAC_TYPE_TIMESTAMP: DATETIME,
    yacli.YAC_TYPE_YM_INTERVAL: YEARDELTA,
    yacli.YAC_TYPE_DS_INTERVAL: TIMEDELTA,
    yacli.YAC_TYPE_CHAR: CHAR,
    yacli.YAC_TYPE_NCHAR: NCHAR,
    yacli.YAC_TYPE_VARCHAR: VARCHAR,
    yacli.YAC_TYPE_NVARCHAR: NVARCHAR,
    yacli.YAC_TYPE_BINARY: BINARY,
    yacli.YAC_TYPE_CLOB: CLOB,
    yacli.YAC_TYPE_BLOB: BLOB,
    yacli.YAC_TYPE_BIT: BIT,
    yacli.YAC_TYPE_ROWID: ROWID,
    yacli.YAC_TYPE_NCLOB: NCLOB,
    yacli.YAC_TYPE_CURSOR: exceptions.NotSupportedError,
    yacli.YAC_TYPE_JSON: JSON,
    yacli.YAC_TYPE_NUMERIC_FLOAT: exceptions.NotSupportedError,
}
