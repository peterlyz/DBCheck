from ctypes import POINTER, c_char_p, cast

from yasdb.libs import yacli, exceptions
from yasdb.commons import YacUtil, LOB_BUFFER_SIZE


class LobValue:
    def __init__(
        self, conn, yac_type: yacli.YacType, is_tmp: bool, free_with_conn: bool
    ) -> None:
        self._conn = conn
        self._loc = yacli.YacLobLocator()
        self._loc_ptr = POINTER(yacli.YacLobLocator)(self._loc)
        self._loc_pptr = POINTER(POINTER(yacli.YacLobLocator))(self._loc_ptr)
        self.yac_type = yac_type
        self.index = -1
        self.length = -1
        self.chunksize = -1
        self.is_tmp = is_tmp
        self._free_with_conn = free_with_conn
        self.alloc()

    @property
    def locator(self):
        return self._loc_ptr

    @property
    def locator_ptr(self):
        return self._loc_pptr

    @property
    def handler(self):
        return self._conn.handler

    def alloc(self):
        self._alloc_lob_desc()
        if self.is_tmp:
            self._create_lob_temporary()

    def free(self):
        if self.is_tmp:
            self._free_lob_temporary()
        self._free_lob_desc()

    def write(self, data: bytes):
        value_ptr = cast(data, POINTER(yacli.YacUint8))
        size = len(data)
        self._lob_write(value_ptr, size)

    def read(self) -> bytearray:
        return self._lob_read()

    def _alloc_lob_desc(self):
        ret = yacli.yacLobDescAlloc(self.handler, self.yac_type, self._loc_pptr)
        YacUtil.assert_ret(ret)
        if self._free_with_conn:
            self._conn.lobs.append(self)
        return

    def _free_lob_desc(self):
        ret = yacli.yacLobDescFree(self.locator, self.yac_type)
        YacUtil.assert_ret(ret)

    def _get_lob_length(self):
        size_ptr = YacUtil.alloc_yac_uint64(0)
        ret = yacli.yacLobGetLength(self.handler, self.locator, size_ptr)
        YacUtil.assert_ret(ret)
        self.length = YacUtil.pointer_value(size_ptr)
        return self.length

    def _get_lob_chunksize(self):
        size_ptr = YacUtil.alloc_yac_uint16(0)
        ret = yacli.yacLobGetChunkSize(self.handler, self.locator, size_ptr)
        YacUtil.assert_ret(ret)
        self.chunksize = YacUtil.pointer_value(size_ptr)
        return self.chunksize

    def _create_lob_temporary(self):
        ret = yacli.yacLobCreateTemporary(self.handler, self.locator)
        YacUtil.assert_ret(ret)

    def _free_lob_temporary(self):
        ret = yacli.yacLobFreeTemporary(self.handler, self.locator)
        YacUtil.assert_ret(ret)

    def _lob_write(self, value_ptr, size: int):
        # if not size:
        #     raise exceptions.EmptyToWrite

        bytes_ptr = YacUtil.alloc_yac_uint64()
        ret = yacli.yacLobWrite(
            self.handler, self.locator, bytes_ptr, value_ptr, yacli.YacUint64(size)
        )
        YacUtil.assert_ret(ret)

    def _lob_read(self) -> bytes:
        buflen = yacli.YacUint64(LOB_BUFFER_SIZE)
        data = bytearray()
        while True:
            c_data = (yacli.YacUint8 * LOB_BUFFER_SIZE)()
            value_ptr = POINTER(yacli.YacUint8)(c_data)
            given_size_ptr = YacUtil.alloc_yac_uint64(LOB_BUFFER_SIZE)
            yacli.yacLobRead(
                self.handler, self.locator, given_size_ptr, value_ptr, buflen
            )
            given_size = YacUtil.pointer_value(given_size_ptr)
            if given_size <= 0:
                break
            data.extend(c_data[0:given_size])
            
        return bytes(data)
