from ctypes import POINTER
from ctypes import create_string_buffer

from yasdb.libs import yacli


class YasdbError(Exception):
    pass


class Warning(Warning, YasdbError):
    pass


class Error(YasdbError):
    pass


class InterfaceError(Error):
    pass


class DatabaseError(Error):
    pass


class DataError(DatabaseError):
    pass


class OperationalError(DatabaseError):
    pass


class IntegrityError(DatabaseError):
    pass


class InternalError(DatabaseError):
    pass


class ProgrammingError(DatabaseError):
    pass


class NotSupportedError(DatabaseError):
    pass


class GetYasdbErrorFailed(DatabaseError):
    def __str__(self) -> str:
        return "get yasdb last error failed"


class YasdbErr(object):
    def __init__(self) -> None:

        self.code = yacli.YacInt32()
        self.size_len = 1024
        self.msg = create_string_buffer(self.size_len)
        self.sql_state = create_string_buffer(self.size_len)
        self.pos = yacli.YacTextPos()

    def to_error_msg(self) -> str:
        if self.line > 0 or self.column > 0:
            return "[{}:{}]YAS-{:05d} {}".format(
                self.line, self.column, self.code.value, self.msg.value.decode("utf-8")
            )
        return "YAS-{:05d} {}".format(self.code.value, self.msg.value.decode("utf-8"))

    def assert_last_error(self):
        _code_ptr = POINTER(yacli.YacInt32)
        _msg_ptr = POINTER(yacli.YacChar)
        _state_ptr = POINTER(yacli.YacChar)
        _pos_ptr = POINTER(yacli.YacTextPos)
        ret = yacli.yacGetDiagRec(
            _code_ptr(self.code),
            _msg_ptr(self.msg),
            self.size_len,
            None,
            _state_ptr(self.sql_state),
            self.size_len,
            _pos_ptr(self.pos),
        )
        if ret != yacli.YAC_SUCCESS:
            return GetYasdbErrorFailed()

        self.line = self.pos.line
        self.column = self.pos.column
        if self.code.value == 0:
            return None
        msg = str(self.to_error_msg())
        return DatabaseError(msg)
