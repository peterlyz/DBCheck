r"""Wrapper for yacli.h

Generated with:
/usr/local/bin/ctypesgen yacli.h -o yacli.py

Do not modify this file.
"""

__docformat__ = "restructuredtext"

# Begin preamble for Python v(3, 2)

import ctypes, os, sys
from ctypes import *

_int_types = (c_int16, c_int32)
if hasattr(ctypes, "c_int64"):
    # Some builds of ctypes apparently do not have c_int64
    # defined; it's a pretty good bet that these builds do not
    # have 64-bit pointers.
    _int_types += (c_int64,)
for t in _int_types:
    if sizeof(t) == sizeof(c_size_t):
        c_ptrdiff_t = t
del t
del _int_types


class UserString:
    def __init__(self, seq):
        if isinstance(seq, bytes):
            self.data = seq
        elif isinstance(seq, UserString):
            self.data = seq.data[:]
        else:
            self.data = str(seq).encode()

    def __bytes__(self):
        return self.data

    def __str__(self):
        return self.data.decode()

    def __repr__(self):
        return repr(self.data)

    def __int__(self):
        return int(self.data.decode())

    def __long__(self):
        return int(self.data.decode())

    def __float__(self):
        return float(self.data.decode())

    def __complex__(self):
        return complex(self.data.decode())

    def __hash__(self):
        return hash(self.data)

    def __cmp__(self, string):
        if isinstance(string, UserString):
            return cmp(self.data, string.data)
        else:
            return cmp(self.data, string)

    def __le__(self, string):
        if isinstance(string, UserString):
            return self.data <= string.data
        else:
            return self.data <= string

    def __lt__(self, string):
        if isinstance(string, UserString):
            return self.data < string.data
        else:
            return self.data < string

    def __ge__(self, string):
        if isinstance(string, UserString):
            return self.data >= string.data
        else:
            return self.data >= string

    def __gt__(self, string):
        if isinstance(string, UserString):
            return self.data > string.data
        else:
            return self.data > string

    def __eq__(self, string):
        if isinstance(string, UserString):
            return self.data == string.data
        else:
            return self.data == string

    def __ne__(self, string):
        if isinstance(string, UserString):
            return self.data != string.data
        else:
            return self.data != string

    def __contains__(self, char):
        return char in self.data

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        return self.__class__(self.data[index])

    def __getslice__(self, start, end):
        start = max(start, 0)
        end = max(end, 0)
        return self.__class__(self.data[start:end])

    def __add__(self, other):
        if isinstance(other, UserString):
            return self.__class__(self.data + other.data)
        elif isinstance(other, bytes):
            return self.__class__(self.data + other)
        else:
            return self.__class__(self.data + str(other).encode())

    def __radd__(self, other):
        if isinstance(other, bytes):
            return self.__class__(other + self.data)
        else:
            return self.__class__(str(other).encode() + self.data)

    def __mul__(self, n):
        return self.__class__(self.data * n)

    __rmul__ = __mul__

    def __mod__(self, args):
        return self.__class__(self.data % args)

    # the following methods are defined in alphabetical order:
    def capitalize(self):
        return self.__class__(self.data.capitalize())

    def center(self, width, *args):
        return self.__class__(self.data.center(width, *args))

    def count(self, sub, start=0, end=sys.maxsize):
        return self.data.count(sub, start, end)

    def decode(self, encoding=None, errors=None):  # XXX improve this?
        if encoding:
            if errors:
                return self.__class__(self.data.decode(encoding, errors))
            else:
                return self.__class__(self.data.decode(encoding))
        else:
            return self.__class__(self.data.decode())

    def encode(self, encoding=None, errors=None):  # XXX improve this?
        if encoding:
            if errors:
                return self.__class__(self.data.encode(encoding, errors))
            else:
                return self.__class__(self.data.encode(encoding))
        else:
            return self.__class__(self.data.encode())

    def endswith(self, suffix, start=0, end=sys.maxsize):
        return self.data.endswith(suffix, start, end)

    def expandtabs(self, tabsize=8):
        return self.__class__(self.data.expandtabs(tabsize))

    def find(self, sub, start=0, end=sys.maxsize):
        return self.data.find(sub, start, end)

    def index(self, sub, start=0, end=sys.maxsize):
        return self.data.index(sub, start, end)

    def isalpha(self):
        return self.data.isalpha()

    def isalnum(self):
        return self.data.isalnum()

    def isdecimal(self):
        return self.data.isdecimal()

    def isdigit(self):
        return self.data.isdigit()

    def islower(self):
        return self.data.islower()

    def isnumeric(self):
        return self.data.isnumeric()

    def isspace(self):
        return self.data.isspace()

    def istitle(self):
        return self.data.istitle()

    def isupper(self):
        return self.data.isupper()

    def join(self, seq):
        return self.data.join(seq)

    def ljust(self, width, *args):
        return self.__class__(self.data.ljust(width, *args))

    def lower(self):
        return self.__class__(self.data.lower())

    def lstrip(self, chars=None):
        return self.__class__(self.data.lstrip(chars))

    def partition(self, sep):
        return self.data.partition(sep)

    def replace(self, old, new, maxsplit=-1):
        return self.__class__(self.data.replace(old, new, maxsplit))

    def rfind(self, sub, start=0, end=sys.maxsize):
        return self.data.rfind(sub, start, end)

    def rindex(self, sub, start=0, end=sys.maxsize):
        return self.data.rindex(sub, start, end)

    def rjust(self, width, *args):
        return self.__class__(self.data.rjust(width, *args))

    def rpartition(self, sep):
        return self.data.rpartition(sep)

    def rstrip(self, chars=None):
        return self.__class__(self.data.rstrip(chars))

    def split(self, sep=None, maxsplit=-1):
        return self.data.split(sep, maxsplit)

    def rsplit(self, sep=None, maxsplit=-1):
        return self.data.rsplit(sep, maxsplit)

    def splitlines(self, keepends=0):
        return self.data.splitlines(keepends)

    def startswith(self, prefix, start=0, end=sys.maxsize):
        return self.data.startswith(prefix, start, end)

    def strip(self, chars=None):
        return self.__class__(self.data.strip(chars))

    def swapcase(self):
        return self.__class__(self.data.swapcase())

    def title(self):
        return self.__class__(self.data.title())

    def translate(self, *args):
        return self.__class__(self.data.translate(*args))

    def upper(self):
        return self.__class__(self.data.upper())

    def zfill(self, width):
        return self.__class__(self.data.zfill(width))


class MutableString(UserString):
    """mutable string objects

    Python strings are immutable objects.  This has the advantage, that
    strings may be used as dictionary keys.  If this property isn't needed
    and you insist on changing string values in place instead, you may cheat
    and use MutableString.

    But the purpose of this class is an educational one: to prevent
    people from inventing their own mutable string class derived
    from UserString and than forget thereby to remove (override) the
    __hash__ method inherited from UserString.  This would lead to
    errors that would be very hard to track down.

    A faster and better solution is to rewrite your program using lists."""

    def __init__(self, string=""):
        self.data = string

    def __hash__(self):
        raise TypeError("unhashable type (it is mutable)")

    def __setitem__(self, index, sub):
        if index < 0:
            index += len(self.data)
        if index < 0 or index >= len(self.data):
            raise IndexError
        self.data = self.data[:index] + sub + self.data[index + 1 :]

    def __delitem__(self, index):
        if index < 0:
            index += len(self.data)
        if index < 0 or index >= len(self.data):
            raise IndexError
        self.data = self.data[:index] + self.data[index + 1 :]

    def __setslice__(self, start, end, sub):
        start = max(start, 0)
        end = max(end, 0)
        if isinstance(sub, UserString):
            self.data = self.data[:start] + sub.data + self.data[end:]
        elif isinstance(sub, bytes):
            self.data = self.data[:start] + sub + self.data[end:]
        else:
            self.data = self.data[:start] + str(sub).encode() + self.data[end:]

    def __delslice__(self, start, end):
        start = max(start, 0)
        end = max(end, 0)
        self.data = self.data[:start] + self.data[end:]

    def immutable(self):
        return UserString(self.data)

    def __iadd__(self, other):
        if isinstance(other, UserString):
            self.data += other.data
        elif isinstance(other, bytes):
            self.data += other
        else:
            self.data += str(other).encode()
        return self

    def __imul__(self, n):
        self.data *= n
        return self


class String(MutableString, Union):

    _fields_ = [("raw", POINTER(c_char)), ("data", c_char_p)]

    def __init__(self, obj=""):
        if isinstance(obj, (bytes, UserString)):
            self.data = bytes(obj)
        else:
            self.raw = obj

    def __len__(self):
        return self.data and len(self.data) or 0

    def from_param(cls, obj):
        # Convert None or 0
        if obj is None or obj == 0:
            return cls(POINTER(c_char)())

        # Convert from String
        elif isinstance(obj, String):
            return obj

        # Convert from bytes
        elif isinstance(obj, bytes):
            return cls(obj)

        # Convert from str
        elif isinstance(obj, str):
            return cls(obj.encode())

        # Convert from c_char_p
        elif isinstance(obj, c_char_p):
            return obj

        # Convert from POINTER(c_char)
        elif isinstance(obj, POINTER(c_char)):
            return obj

        # Convert from raw pointer
        elif isinstance(obj, int):
            return cls(cast(obj, POINTER(c_char)))

        # Convert from c_char array
        elif isinstance(obj, c_char * len(obj)):
            return obj

        # Convert from object
        else:
            return String.from_param(obj._as_parameter_)

    from_param = classmethod(from_param)


def ReturnString(obj, func=None, arguments=None):
    return String.from_param(obj)


# As of ctypes 1.0, ctypes does not support custom error-checking
# functions on callbacks, nor does it support custom datatypes on
# callbacks, so we must ensure that all callbacks return
# primitive datatypes.
#
# Non-primitive return values wrapped with UNCHECKED won't be
# typechecked, and will be converted to c_void_p.
def UNCHECKED(type):
    if hasattr(type, "_type_") and isinstance(type._type_, str) and type._type_ != "P":
        return type
    else:
        return c_void_p


# ctypes doesn't have direct support for variadic functions, so we have to write
# our own wrapper class
class _variadic_function(object):
    def __init__(self, func, restype, argtypes, errcheck):
        self.func = func
        self.func.restype = restype
        self.argtypes = argtypes
        if errcheck:
            self.func.errcheck = errcheck

    def _as_parameter_(self):
        # So we can pass this variadic function as a function pointer
        return self.func

    def __call__(self, *args):
        fixed_args = []
        i = 0
        for argtype in self.argtypes:
            # Typecheck what we can
            fixed_args.append(argtype.from_param(args[i]))
            i += 1
        return self.func(*fixed_args + list(args[i:]))


def ord_if_char(value):
    """
    Simple helper used for casts to simple builtin types:  if the argument is a
    string type, it will be converted to it's ordinal value.

    This function will raise an exception if the argument is string with more
    than one characters.
    """
    return ord(value) if (isinstance(value, bytes) or isinstance(value, str)) else value


# End preamble

_libs = {}
_libdirs = []

# Begin loader

import os.path, re, sys, glob
import platform
import ctypes
import ctypes.util


def _environ_path(name):
    if name in os.environ:
        return os.environ[name].split(":")
    else:
        return []


class LibraryLoader(object):
    # library names formatted specifically for platforms
    name_formats = ["%s"]

    class Lookup(object):
        mode = ctypes.DEFAULT_MODE

        def __init__(self, path):
            super(LibraryLoader.Lookup, self).__init__()
            self.access = dict(cdecl=ctypes.CDLL(path, self.mode))

        def get(self, name, calling_convention="cdecl"):
            if calling_convention not in self.access:
                raise LookupError(
                    "Unknown calling convention '{}' for function '{}'".format(
                        calling_convention, name
                    )
                )
            return getattr(self.access[calling_convention], name)

        def has(self, name, calling_convention="cdecl"):
            if calling_convention not in self.access:
                return False
            return hasattr(self.access[calling_convention], name)

        def __getattr__(self, name):
            return getattr(self.access["cdecl"], name)

    def __init__(self):
        self.other_dirs = []

    def __call__(self, libname):
        """Given the name of a library, load it."""
        paths = self.getpaths(libname)
        for path in paths:
            if not os.path.exists(path):
                continue
            try:
                return self.Lookup(path)
            except Exception as ex:
                print("warning: ", ex)

        raise ImportError("Could not load %s." % libname)

    def getpaths(self, libname):
        """Return a list of paths where the library might be found."""
        if os.path.isabs(libname):
            yield libname
        else:
            # search through a prioritized series of locations for the library

            # we first search any specific directories identified by user
            for dir_i in self.other_dirs:
                for fmt in self.name_formats:
                    # dir_i should be absolute already
                    yield os.path.join(dir_i, fmt % libname)

            # then we search the directory where the generated python interface is stored
            for fmt in self.name_formats:
                yield os.path.abspath(
                    os.path.join(os.path.dirname(__file__), fmt % libname)
                )

            # now, use the ctypes tools to try to find the library
            for fmt in self.name_formats:
                path = ctypes.util.find_library(fmt % libname)
                if path:
                    yield path

            # then we search all paths identified as platform-specific lib paths
            for path in self.getplatformpaths(libname):
                yield path

            # Finally, we'll try the users current working directory
            for fmt in self.name_formats:
                yield os.path.abspath(os.path.join(os.path.curdir, fmt % libname))

    def getplatformpaths(self, libname):
        return []


# Darwin (Mac OS X)


class DarwinLibraryLoader(LibraryLoader):
    name_formats = [
        "lib%s.dylib",
        "lib%s.so",
        "lib%s.bundle",
        "%s.dylib",
        "%s.so",
        "%s.bundle",
        "%s",
    ]

    class Lookup(LibraryLoader.Lookup):
        # Darwin requires dlopen to be called with mode RTLD_GLOBAL instead
        # of the default RTLD_LOCAL.  Without this, you end up with
        # libraries not being loadable, resulting in "Symbol not found"
        # errors
        mode = ctypes.RTLD_GLOBAL

    def getplatformpaths(self, libname):
        if os.path.pathsep in libname:
            names = [libname]
        else:
            names = [format % libname for format in self.name_formats]

        for dir in self.getdirs(libname):
            for name in names:
                yield os.path.join(dir, name)

    def getdirs(self, libname):
        """Implements the dylib search as specified in Apple documentation:

        http://developer.apple.com/documentation/DeveloperTools/Conceptual/
            DynamicLibraries/Articles/DynamicLibraryUsageGuidelines.html

        Before commencing the standard search, the method first checks
        the bundle's ``Frameworks`` directory if the application is running
        within a bundle (OS X .app).
        """

        dyld_fallback_library_path = _environ_path("DYLD_FALLBACK_LIBRARY_PATH")
        if not dyld_fallback_library_path:
            dyld_fallback_library_path = [
                os.path.expanduser("~/lib"),
                "/usr/local/lib",
                "/usr/lib",
            ]

        dirs = []

        if "/" in libname:
            dirs.extend(_environ_path("DYLD_LIBRARY_PATH"))
        else:
            dirs.extend(_environ_path("LD_LIBRARY_PATH"))
            dirs.extend(_environ_path("DYLD_LIBRARY_PATH"))

        if hasattr(sys, "frozen") and sys.frozen == "macosx_app":
            dirs.append(os.path.join(os.environ["RESOURCEPATH"], "..", "Frameworks"))

        dirs.extend(dyld_fallback_library_path)

        return dirs


# Posix


class PosixLibraryLoader(LibraryLoader):
    _ld_so_cache = None

    _include = re.compile(r"^\s*include\s+(?P<pattern>.*)")

    class _Directories(dict):
        def __init__(self):
            self.order = 0

        def add(self, directory):
            if len(directory) > 1:
                directory = directory.rstrip(os.path.sep)
            # only adds and updates order if exists and not already in set
            if not os.path.exists(directory):
                return
            o = self.setdefault(directory, self.order)
            if o == self.order:
                self.order += 1

        def extend(self, directories):
            for d in directories:
                self.add(d)

        def ordered(self):
            return (i[0] for i in sorted(self.items(), key=lambda D: D[1]))

    def _get_ld_so_conf_dirs(self, conf, dirs):
        """
        Recursive funtion to help parse all ld.so.conf files, including proper
        handling of the `include` directive.
        """

        try:
            with open(conf) as f:
                for D in f:
                    D = D.strip()
                    if not D:
                        continue

                    m = self._include.match(D)
                    if not m:
                        dirs.add(D)
                    else:
                        for D2 in glob.glob(m.group("pattern")):
                            self._get_ld_so_conf_dirs(D2, dirs)
        except IOError:
            pass

    def _create_ld_so_cache(self):
        # Recreate search path followed by ld.so.  This is going to be
        # slow to build, and incorrect (ld.so uses ld.so.cache, which may
        # not be up-to-date).  Used only as fallback for distros without
        # /sbin/ldconfig.
        #
        # We assume the DT_RPATH and DT_RUNPATH binary sections are omitted.

        directories = self._Directories()
        for name in (
            "LD_LIBRARY_PATH",
            "SHLIB_PATH",  # HPUX
            "LIBPATH",  # OS/2, AIX
            "LIBRARY_PATH",  # BE/OS
        ):
            if name in os.environ:
                directories.extend(os.environ[name].split(os.pathsep))

        self._get_ld_so_conf_dirs("/etc/ld.so.conf", directories)

        bitage = platform.architecture()[0]

        unix_lib_dirs_list = []
        if bitage.startswith("64"):
            # prefer 64 bit if that is our arch
            unix_lib_dirs_list += ["/lib64", "/usr/lib64"]

        # must include standard libs, since those paths are also used by 64 bit
        # installs
        unix_lib_dirs_list += ["/lib", "/usr/lib"]
        if sys.platform.startswith("linux"):
            # Try and support multiarch work in Ubuntu
            # https://wiki.ubuntu.com/MultiarchSpec
            if bitage.startswith("32"):
                # Assume Intel/AMD x86 compat
                unix_lib_dirs_list += ["/lib/i386-linux-gnu", "/usr/lib/i386-linux-gnu"]
            elif bitage.startswith("64"):
                # Assume Intel/AMD x86 compat
                unix_lib_dirs_list += [
                    "/lib/x86_64-linux-gnu",
                    "/usr/lib/x86_64-linux-gnu",
                ]
            else:
                # guess...
                unix_lib_dirs_list += glob.glob("/lib/*linux-gnu")
        directories.extend(unix_lib_dirs_list)

        cache = {}
        lib_re = re.compile(r"lib(.*)\.s[ol]")
        ext_re = re.compile(r"\.s[ol]$")
        for dir in directories.ordered():
            try:
                for path in glob.glob("%s/*.s[ol]*" % dir):
                    file = os.path.basename(path)

                    # Index by filename
                    cache_i = cache.setdefault(file, set())
                    cache_i.add(path)

                    # Index by library name
                    match = lib_re.match(file)
                    if match:
                        library = match.group(1)
                        cache_i = cache.setdefault(library, set())
                        cache_i.add(path)
            except OSError:
                pass

        self._ld_so_cache = cache

    def getplatformpaths(self, libname):
        if self._ld_so_cache is None:
            self._create_ld_so_cache()

        result = self._ld_so_cache.get(libname, set())
        for i in result:
            # we iterate through all found paths for library, since we may have
            # actually found multiple architectures or other library types that
            # may not load
            yield i


# Windows


class WindowsLibraryLoader(LibraryLoader):
    name_formats = ["%s.dll", "lib%s.dll", "%slib.dll", "%s"]

    class Lookup(LibraryLoader.Lookup):
        def __init__(self, path):
            super(WindowsLibraryLoader.Lookup, self).__init__(path)
            self.access["stdcall"] = ctypes.windll.LoadLibrary(path)


# Platform switching

# If your value of sys.platform does not appear in this dict, please contact
# the Ctypesgen maintainers.

loaderclass = {
    "darwin": DarwinLibraryLoader,
    "cygwin": WindowsLibraryLoader,
    "win32": WindowsLibraryLoader,
    "msys": WindowsLibraryLoader,
}

load_library = loaderclass.get(sys.platform, PosixLibraryLoader)()


def add_library_search_dirs(other_dirs):
    """
    Add libraries to search paths.
    If library paths are relative, convert them to absolute with respect to this
    file's directory
    """
    for F in other_dirs:
        if not os.path.isabs(F):
            F = os.path.abspath(F)
        load_library.other_dirs.append(F)


del loaderclass

# End loader

add_library_search_dirs([])

# Begin libraries
_libs["yacli"] = load_library("yascli")

# End libraries
# No modules

YacInt8 = c_int8  # yacli.h: 33

YacUint8 = c_uint8  # yacli.h: 34

YacInt16 = c_int16  # yacli.h: 35

YacUint16 = c_uint16  # yacli.h: 36

YacInt32 = c_int32  # yacli.h: 37

YacUint32 = c_uint32  # yacli.h: 38

YacInt64 = c_int64  # yacli.h: 39

YacUint64 = c_uint64  # yacli.h: 40

YacChar = c_char  # yacli.h: 41

YacBool = c_bool  # yacli.h: 42

YacDouble = c_double  # yacli.h: 43

YacFloat = c_float  # yacli.h: 44

YacDate = YacInt64  # yacli.h: 45

YacShortTime = YacInt64  # yacli.h: 46

YacYMInterval = YacInt32  # yacli.h: 47

YacDSInterval = YacInt64  # yacli.h: 48


# yacli.h: 53
class struct_StYacNumber(Structure):
    pass


struct_StYacNumber._pack_ = 4
struct_StYacNumber.__slots__ = [
    "numberPart",
]
struct_StYacNumber._fields_ = [
    ("numberPart", YacUint8 * int(20)),
]

YacNumber = struct_StYacNumber  # yacli.h: 53


# yacli.h: 58
class struct_StYacRowId(Structure):
    pass


struct_StYacRowId._pack_ = 4
struct_StYacRowId.__slots__ = [
    "rowIdPart",
]
struct_StYacRowId._fields_ = [
    ("rowIdPart", YacUint8 * int(16)),
]

YacRowId = struct_StYacRowId  # yacli.h: 58


# yacli.h: 63
# coredumped in python3.6 linux, do not use (YacUint8 * 12)
class struct_StYacTimestamp(Structure):
    _pack_ = 4
    __slots__ = ["stamp", "bias", "unused"]
    _fields_ = [("stamp", YacInt64), ("bias", YacInt16), ("unused", YacInt16)]


YacTimestamp = struct_StYacTimestamp  # yacli.h: 63

YacVoid = None  # yacli.h: 68

YacPointer = POINTER(YacVoid)  # yacli.h: 69

YacHandle = POINTER(YacVoid)  # yacli.h: 70

YacLobLocator = YacHandle  # yacli.h: 65


# yacli.h: 76
class struct_StYacTextPos(Structure):
    pass


struct_StYacTextPos._pack_ = 4
struct_StYacTextPos.__slots__ = [
    "line",
    "column",
]
struct_StYacTextPos._fields_ = [
    ("line", YacInt32),
    ("column", YacInt32),
]

YacTextPos = struct_StYacTextPos  # yacli.h: 76

enum_EnYacResult = c_int  # yacli.h: 85

YAC_SUCCESS = 0  # yacli.h: 85

YAC_SUCCESS_WITH_INFO = 1  # yacli.h: 85

YAC_ERROR = -1  # yacli.h: 85

YacResult = enum_EnYacResult  # yacli.h: 85

enum_EnYacHandleType = c_int  # yacli.h: 93

YAC_HANDLE_UNKNOWN = 0  # yacli.h: 93

YAC_HANDLE_ENV = 1  # yacli.h: 93

YAC_HANDLE_DBC = 2  # yacli.h: 93

YAC_HANDLE_STMT = 3  # yacli.h: 93

YacHandleType = enum_EnYacHandleType  # yacli.h: 93

enum_EnYacType = c_int  # yacli.h: 124

YAC_TYPE_UNKNOWN = 0  # yacli.h: 124

YAC_TYPE_BOOL = 1  # yacli.h: 124

YAC_TYPE_TINYINT = 2  # yacli.h: 124

YAC_TYPE_SMALLINT = 3  # yacli.h: 124

YAC_TYPE_INTEGER = 4  # yacli.h: 124

YAC_TYPE_BIGINT = 5  # yacli.h: 124

YAC_TYPE_FLOAT = 10  # yacli.h: 124

YAC_TYPE_DOUBLE = 11  # yacli.h: 124

YAC_TYPE_NUMBER = 12  # yacli.h: 124

YAC_TYPE_DATE = 13  # yacli.h: 124

YAC_TYPE_SHORTTIME = 15  # yacli.h: 124

YAC_TYPE_TIMESTAMP = 16  # yacli.h: 124

YAC_TYPE_YM_INTERVAL = 19  # yacli.h: 124

YAC_TYPE_DS_INTERVAL = 20  # yacli.h: 124

YAC_TYPE_CHAR = 24  # yacli.h: 124

YAC_TYPE_NCHAR = 25  # yacli.h: 124

YAC_TYPE_VARCHAR = 26  # yacli.h: 124

YAC_TYPE_NVARCHAR = 27  # yacli.h: 124

YAC_TYPE_BINARY = 28  # yacli.h: 124

YAC_TYPE_CLOB = 29  # yacli.h: 124

YAC_TYPE_BLOB = 30  # yacli.h: 124

YAC_TYPE_BIT = 31  # yacli.h: 124

YAC_TYPE_ROWID = 32  # yacli.h: 124

YAC_TYPE_NCLOB = 33  # yacli.h: 124

YAC_TYPE_CURSOR = 34  # yacli.h: 124

YAC_TYPE_JSON = 35  # yacli.h: 124

YAC_TYPE_NUMERIC_FLOAT = 40  # yacli.h: 124

YacType = enum_EnYacType  # yacli.h: 124

enum_EnYacExtType = c_int  # yacli.h: 158

YAC_SQLT_UNKNOWN = 0  # yacli.h: 158

YAC_SQLT_BOOL = 1  # yacli.h: 158

YAC_SQLT_TINYINT = 2  # yacli.h: 158

YAC_SQLT_SMALLINT = 3  # yacli.h: 158

YAC_SQLT_INTEGER = 4  # yacli.h: 158

YAC_SQLT_BIGINT = 5  # yacli.h: 158

YAC_SQLT_FLOAT = 10  # yacli.h: 158

YAC_SQLT_DOUBLE = 11  # yacli.h: 158

YAC_SQLT_NUMBER = 12  # yacli.h: 158

YAC_SQLT_DATE = 13  # yacli.h: 158

YAC_SQLT_SHORTTIME = 15  # yacli.h: 158

YAC_SQLT_TIMESTAMP = 16  # yacli.h: 158

YAC_SQLT_YM_INTERVAL = 19  # yacli.h: 158

YAC_SQLT_DS_INTERVAL = 20  # yacli.h: 158

YAC_SQLT_CHAR = 24  # yacli.h: 158

YAC_SQLT_VARCHAR = 26  # yacli.h: 158

YAC_SQLT_BINARY = 28  # yacli.h: 158

YAC_SQLT_CLOB = 29  # yacli.h: 158

YAC_SQLT_BLOB = 30  # yacli.h: 158

YAC_SQLT_BIT = 31  # yacli.h: 158

YAC_SQLT_ROWID = 32  # yacli.h: 158

YAC_SQLT_NCLOB = 33  # yacli.h: 158

YAC_SQLT_CURSOR = 34  # yacli.h: 158

YAC_SQLT_JSON = 35  # yacli.h: 158

YAC_SQLT_CHAR2 = 100  # yacli.h: 158

YAC_SQLT_VARCHAR2 = 101  # yacli.h: 158

YAC_SQLT_BINARY2 = 102  # yacli.h: 158

YacExtType = enum_EnYacExtType  # yacli.h: 158

enum_EnYacParamDirection = c_int  # yacli.h: 165

YAC_PARAM_INPUT = 1  # yacli.h: 165

YAC_PARAM_OUTPUT = 2  # yacli.h: 165

YAC_PARAM_INOUT = 3  # yacli.h: 165

YacParamDirection = enum_EnYacParamDirection  # yacli.h: 165

enum_EnYacCharsetCode = c_int  # yacli.h: 174

YAC_CHARSET_ASCII = 0  # yacli.h: 174

YAC_CHARSET_GBK = 1  # yacli.h: 174

YAC_CHARSET_UTF8 = 2  # yacli.h: 174

YAC_CHARSET_ISO88591 = 3  # yacli.h: 174

YAC_CHARSET_UTF16 = 4  # yacli.h: 174

YacCharsetCode = enum_EnYacCharsetCode  # yacli.h: 174

enum_EnYacEnvAttr = c_int  # yacli.h: 179

YAC_ATTR_CHARSET_CODE = 62  # yacli.h: 179

YAC_ATTR_CLIENT_DRIVER = 66

YacEnvAttr = enum_EnYacEnvAttr  # yacli.h: 179

enum_EnYacConnAttr = c_int  # yacli.h: 189

YAC_ATTR_AUTOCOMMIT = 3  # yacli.h: 189

YAC_ATTR_LOGIN_TIMEOUT = 4  # yacli.h: 189

YAC_ATTR_PACKET_SIZE = 6  # yacli.h: 189

YAC_ATTR_TXN_ISOLATION = 7  # yacli.h: 189

YAC_ATTR_CREDT = 11  # yacli.h: 189

YAC_ATTR_MAX_CHARSET_RATIO = 12  # yacli.h: 189

YAC_ATTR_MAX_NCHARSET_RATIO = 17  # yacli.h: 189

YacConnAttr = enum_EnYacConnAttr  # yacli.h: 189

enum_EnYacTxnIsolation = c_int  # yacli.h: 196

YAC_TXN_READ_COMMITTED = 0  # yacli.h: 196

YAC_TXN_CURR_COMMITTED = 1  # yacli.h: 196

YAC_TXN_SERIALIZABLE = 2  # yacli.h: 196

YacTxnIsolation = enum_EnYacTxnIsolation  # yacli.h: 196

enum_EnYacStmtAttr = c_int  # yacli.h: 208

YAC_ATTR_PARAMSET_SIZE = 100  # yacli.h: 208

YAC_ATTR_ROWSET_SIZE = 101  # yacli.h: 208

YAC_ATTR_ROWS_FETECHED = 102  # yacli.h: 208

YAC_ATTR_ROWS_AFFECTED = 103  # yacli.h: 208

YAC_ATTR_CURSOR_EOF = 104  # yacli.h: 208

YAC_ATTR_SQLTYPE = 105  # yacli.h: 208

YAC_ATTR_IMPLICIT_RESULT_COUNT = 113  # yacli.h: 208

YAC_ATTR_GET_DATA_SUPPORT = 114  # yacli.h: 208

YacStmtAttr = enum_EnYacStmtAttr  # yacli.h: 208

enum_EnYacColAttr = c_int  # yacli.h: 222

YAC_COL_ATTR_DISPLAY_SIZE = 0  # yacli.h: 222

YAC_COL_ATTR_NAME = 1  # yacli.h: 222

YAC_COL_ATTR_SIZE = 2  # yacli.h: 222

YAC_COL_ATTR_TYPE = 3  # yacli.h: 222

YAC_COL_ATTR_PRECISION = 4  # yacli.h: 222

YAC_COL_ATTR_SCALE = 5  # yacli.h: 222

YAC_COL_ATTR_NULLABLE = 6  # yacli.h: 222

YAC_COL_ATTR_CHAR_SIZE = 7  # yacli.h: 222

YAC_COL_ATTR_CHAR_USED = 8  # yacli.h: 222

YAC_COL_ATTR_DISPLAY_CHAR_SIZE = 9  # yacli.h: 222

YacColAttr = enum_EnYacColAttr  # yacli.h: 222

enum_EnYacResultType = c_int  # yacli.h: 227

YAC_RESULT_TYPE_SELECT = 0  # yacli.h: 227

YacResultType = enum_EnYacResultType  # yacli.h: 227

enum_EnYacSQLType = c_int  # yacli.h: 241

YAC_SQLTYPE_UNKNOWN = 0  # yacli.h: 241

YAC_SQLTYPE_QUERY = 1  # yacli.h: 241

YAC_SQLTYPE_INSERT = 2  # yacli.h: 241

YAC_SQLTYPE_UPDATE = 3  # yacli.h: 241

YAC_SQLTYPE_DELETE = 4  # yacli.h: 241

YAC_SQLTYPE_MERGE = 5  # yacli.h: 241

YAC_SQLTYPE_GRANT = 69  # yacli.h: 241

YAC_SQLTYPE_REVOKE = 70  # yacli.h: 241

YAC_SQLTYPE_COMMIT = 129  # yacli.h: 241

YAC_SQLTYPE_ROLLBACK = 130  # yacli.h: 241

YacSQLType = enum_EnYacSQLType  # yacli.h: 241

enum_EnYacTempLobType = c_int  # yacli.h: 247

YAC_TEMP_BLOB = 0  # yacli.h: 247

YAC_TEMP_CLOB = 1  # yacli.h: 247

YAC_TEMP_NCLOB = 2  # yacli.h: 247

YacTempLobType = enum_EnYacTempLobType  # yacli.h: 247

# yacli.h: 250
for _lib in _libs.values():
    if not _lib.has("yacGetDiagRec", "cdecl"):
        continue
    yacGetDiagRec = _lib.get("yacGetDiagRec", "cdecl")
    yacGetDiagRec.argtypes = [
        POINTER(YacInt32),
        POINTER(YacChar),
        YacInt32,
        POINTER(YacInt32),
        POINTER(YacChar),
        YacInt32,
        POINTER(YacTextPos),
    ]
    yacGetDiagRec.restype = YacResult
    break

# yacli.h: 253
for _lib in _libs.values():
    if not _lib.has("yacAllocHandle", "cdecl"):
        continue
    yacAllocHandle = _lib.get("yacAllocHandle", "cdecl")
    yacAllocHandle.argtypes = [YacHandleType, YacHandle, POINTER(YacHandle)]
    yacAllocHandle.restype = YacResult
    break

# yacli.h: 254
for _lib in _libs.values():
    if not _lib.has("yacFreeHandle", "cdecl"):
        continue
    yacFreeHandle = _lib.get("yacFreeHandle", "cdecl")
    yacFreeHandle.argtypes = [YacHandleType, YacHandle]
    yacFreeHandle.restype = YacResult
    break

# yacli.h: 257
for _lib in _libs.values():
    if not _lib.has("yacConnect", "cdecl"):
        continue
    yacConnect = _lib.get("yacConnect", "cdecl")
    yacConnect.argtypes = [
        YacHandle,
        POINTER(YacChar),
        YacInt16,
        POINTER(YacChar),
        YacInt16,
        POINTER(YacChar),
        YacInt16,
    ]
    yacConnect.restype = YacResult
    break

# yacli.h: 258
for _lib in _libs.values():
    if not _lib.has("yacDisconnect", "cdecl"):
        continue
    yacDisconnect = _lib.get("yacDisconnect", "cdecl")
    yacDisconnect.argtypes = [YacHandle]
    yacDisconnect.restype = YacVoid
    break

# yacli.h: 261
for _lib in _libs.values():
    if not _lib.has("yacDirectExecute", "cdecl"):
        continue
    yacDirectExecute = _lib.get("yacDirectExecute", "cdecl")
    yacDirectExecute.argtypes = [YacHandle, POINTER(YacChar), YacInt32]
    yacDirectExecute.restype = YacResult
    break

# yacli.h: 262
for _lib in _libs.values():
    if not _lib.has("yacPrepare", "cdecl"):
        continue
    yacPrepare = _lib.get("yacPrepare", "cdecl")
    yacPrepare.argtypes = [YacHandle, POINTER(YacChar), YacInt32]
    yacPrepare.restype = YacResult
    break

# yacli.h: 263
for _lib in _libs.values():
    if not _lib.has("yacExecute", "cdecl"):
        continue
    yacExecute = _lib.get("yacExecute", "cdecl")
    yacExecute.argtypes = [YacHandle]
    yacExecute.restype = YacResult
    break

# yacli.h: 266
for _lib in _libs.values():
    if not _lib.has("yacFetch", "cdecl"):
        continue
    yacFetch = _lib.get("yacFetch", "cdecl")
    yacFetch.argtypes = [YacHandle, POINTER(YacUint32)]
    yacFetch.restype = YacResult
    break

# yacli.h: 269
for _lib in _libs.values():
    if not _lib.has("yacCommit", "cdecl"):
        continue
    yacCommit = _lib.get("yacCommit", "cdecl")
    yacCommit.argtypes = [YacHandle]
    yacCommit.restype = YacResult
    break

# yacli.h: 270
for _lib in _libs.values():
    if not _lib.has("yacRollback", "cdecl"):
        continue
    yacRollback = _lib.get("yacRollback", "cdecl")
    yacRollback.argtypes = [YacHandle]
    yacRollback.restype = YacResult
    break

# yacli.h: 273
for _lib in _libs.values():
    if not _lib.has("yacCancel", "cdecl"):
        continue
    yacCancel = _lib.get("yacCancel", "cdecl")
    yacCancel.argtypes = [YacHandle]
    yacCancel.restype = YacResult
    break

# yacli.h: 276
for _lib in _libs.values():
    if not _lib.has("yacSetEnvAttr", "cdecl"):
        continue
    yacSetEnvAttr = _lib.get("yacSetEnvAttr", "cdecl")
    yacSetEnvAttr.argtypes = [YacHandle, YacEnvAttr, POINTER(YacVoid), YacInt32]
    yacSetEnvAttr.restype = YacResult
    break

# yacli.h: 277
for _lib in _libs.values():
    if not _lib.has("yacGetEnvAttr", "cdecl"):
        continue
    yacGetEnvAttr = _lib.get("yacGetEnvAttr", "cdecl")
    yacGetEnvAttr.argtypes = [
        YacHandle,
        YacEnvAttr,
        POINTER(YacVoid),
        YacInt32,
        POINTER(YacInt32),
    ]
    yacGetEnvAttr.restype = YacResult
    break

# yacli.h: 278
for _lib in _libs.values():
    if not _lib.has("yacSetConnAttr", "cdecl"):
        continue
    yacSetConnAttr = _lib.get("yacSetConnAttr", "cdecl")
    yacSetConnAttr.argtypes = [YacHandle, YacConnAttr, POINTER(YacVoid), YacInt32]
    yacSetConnAttr.restype = YacResult
    break

# yacli.h: 279
for _lib in _libs.values():
    if not _lib.has("yacGetConnAttr", "cdecl"):
        continue
    yacGetConnAttr = _lib.get("yacGetConnAttr", "cdecl")
    yacGetConnAttr.argtypes = [
        YacHandle,
        YacConnAttr,
        POINTER(YacVoid),
        YacInt32,
        POINTER(YacInt32),
    ]
    yacGetConnAttr.restype = YacResult
    break

# yacli.h: 280
for _lib in _libs.values():
    if not _lib.has("yacSetStmtAttr", "cdecl"):
        continue
    yacSetStmtAttr = _lib.get("yacSetStmtAttr", "cdecl")
    yacSetStmtAttr.argtypes = [YacHandle, YacStmtAttr, POINTER(YacVoid), YacInt32]
    yacSetStmtAttr.restype = YacResult
    break

# yacli.h: 281
for _lib in _libs.values():
    if not _lib.has("yacGetStmtAttr", "cdecl"):
        continue
    yacGetStmtAttr = _lib.get("yacGetStmtAttr", "cdecl")
    yacGetStmtAttr.argtypes = [
        YacHandle,
        YacStmtAttr,
        POINTER(YacVoid),
        YacInt32,
        POINTER(YacInt32),
    ]
    yacGetStmtAttr.restype = YacResult
    break

# yacli.h: 284
for _lib in _libs.values():
    if not _lib.has("yacBindColumn", "cdecl"):
        continue
    yacBindColumn = _lib.get("yacBindColumn", "cdecl")
    yacBindColumn.argtypes = [
        YacHandle,
        YacUint16,
        YacUint32,
        YacPointer,
        YacInt32,
        POINTER(YacInt32),
    ]
    yacBindColumn.restype = YacResult
    break

# yacli.h: 285
for _lib in _libs.values():
    if not _lib.has("yacBindParameter", "cdecl"):
        continue
    yacBindParameter = _lib.get("yacBindParameter", "cdecl")
    yacBindParameter.argtypes = [
        YacHandle,
        YacUint16,
        YacParamDirection,
        YacUint32,
        YacPointer,
        YacInt32,
        YacInt32,
        POINTER(YacInt32),
    ]
    yacBindParameter.restype = YacResult
    break

# yacli.h: 286
for _lib in _libs.values():
    if not _lib.has("yacBindParameterByName", "cdecl"):
        continue
    yacBindParameterByName = _lib.get("yacBindParameterByName", "cdecl")
    yacBindParameterByName.argtypes = [
        YacHandle,
        POINTER(YacChar),
        YacParamDirection,
        YacUint32,
        YacPointer,
        YacInt32,
        YacInt32,
        POINTER(YacInt32),
    ]
    yacBindParameterByName.restype = YacResult
    break

# yacli.h: 289
for _lib in _libs.values():
    if not _lib.has("yacGetData", "cdecl"):
        continue
    yacGetData = _lib.get("yacGetData", "cdecl")
    yacGetData.argtypes = [
        YacHandle,
        YacUint16,
        YacUint32,
        YacUint32,
        YacPointer,
        YacInt32,
        POINTER(YacInt32),
    ]
    yacGetData.restype = YacResult
    break

# yacli.h: 292
for _lib in _libs.values():
    if not _lib.has("yacColAttribute", "cdecl"):
        continue
    yacColAttribute = _lib.get("yacColAttribute", "cdecl")
    yacColAttribute.argtypes = [
        YacHandle,
        YacUint16,
        YacColAttr,
        POINTER(YacVoid),
        YacInt32,
        POINTER(YacInt32),
    ]
    yacColAttribute.restype = YacResult
    break

# yacli.h: 293
for _lib in _libs.values():
    if not _lib.has("yacNumResultCols", "cdecl"):
        continue
    yacNumResultCols = _lib.get("yacNumResultCols", "cdecl")
    yacNumResultCols.argtypes = [YacHandle, POINTER(YacInt16)]
    yacNumResultCols.restype = YacResult
    break

# yacli.h: 294
for _lib in _libs.values():
    if not _lib.has("yacNumParams", "cdecl"):
        continue
    yacNumParams = _lib.get("yacNumParams", "cdecl")
    yacNumParams.argtypes = [YacHandle, POINTER(YacUint16)]
    yacNumParams.restype = YacResult
    break

# yacli.h: 297
for _lib in _libs.values():
    if not _lib.has("yacStmtGetNextResult", "cdecl"):
        continue
    yacStmtGetNextResult = _lib.get("yacStmtGetNextResult", "cdecl")
    yacStmtGetNextResult.argtypes = [YacHandle, POINTER(YacHandle), POINTER(YacUint32)]
    yacStmtGetNextResult.restype = YacResult
    break

# yacli.h: 300
for _lib in _libs.values():
    if not _lib.has("yacLobDescAlloc", "cdecl"):
        continue
    yacLobDescAlloc = _lib.get("yacLobDescAlloc", "cdecl")
    yacLobDescAlloc.argtypes = [YacHandle, YacType, POINTER(POINTER(YacLobLocator))]
    yacLobDescAlloc.restype = YacResult
    break

# yacli.h: 301
for _lib in _libs.values():
    if not _lib.has("yacLobDescFree", "cdecl"):
        continue
    yacLobDescFree = _lib.get("yacLobDescFree", "cdecl")
    yacLobDescFree.argtypes = [POINTER(YacLobLocator), YacType]
    yacLobDescFree.restype = YacResult
    break

# yacli.h: 302
for _lib in _libs.values():
    if not _lib.has("yacLobGetChunkSize", "cdecl"):
        continue
    yacLobGetChunkSize = _lib.get("yacLobGetChunkSize", "cdecl")
    yacLobGetChunkSize.argtypes = [
        YacHandle,
        POINTER(YacLobLocator),
        POINTER(YacUint16),
    ]
    yacLobGetChunkSize.restype = YacResult
    break

# yacli.h: 303
for _lib in _libs.values():
    if not _lib.has("yacLobGetLength", "cdecl"):
        continue
    yacLobGetLength = _lib.get("yacLobGetLength", "cdecl")
    yacLobGetLength.argtypes = [YacHandle, POINTER(YacLobLocator), POINTER(YacUint64)]
    yacLobGetLength.restype = YacResult
    break

# yacli.h: 304
for _lib in _libs.values():
    if not _lib.has("yacLobRead", "cdecl"):
        continue
    yacLobRead = _lib.get("yacLobRead", "cdecl")
    yacLobRead.argtypes = [
        YacHandle,
        POINTER(YacLobLocator),
        POINTER(YacUint64),
        POINTER(YacUint8),
        YacUint64,
    ]
    yacLobRead.restype = YacResult
    break

# yacli.h: 305
for _lib in _libs.values():
    if not _lib.has("yacLobWrite", "cdecl"):
        continue
    yacLobWrite = _lib.get("yacLobWrite", "cdecl")
    yacLobWrite.argtypes = [
        YacHandle,
        POINTER(YacLobLocator),
        POINTER(YacUint64),
        POINTER(YacUint8),
        YacUint64,
    ]
    yacLobWrite.restype = YacResult
    break

# yacli.h: 306
for _lib in _libs.values():
    if not _lib.has("yacLobCreateTemporary", "cdecl"):
        continue
    yacLobCreateTemporary = _lib.get("yacLobCreateTemporary", "cdecl")
    yacLobCreateTemporary.argtypes = [YacHandle, POINTER(YacLobLocator)]
    yacLobCreateTemporary.restype = YacResult
    break

# yacli.h: 307
for _lib in _libs.values():
    if not _lib.has("yacLobFreeTemporary", "cdecl"):
        continue
    yacLobFreeTemporary = _lib.get("yacLobFreeTemporary", "cdecl")
    yacLobFreeTemporary.argtypes = [YacHandle, POINTER(YacLobLocator)]
    yacLobFreeTemporary.restype = YacResult
    break

# yacli.h: 308
for _lib in _libs.values():
    if not _lib.has("yacLobCharSetId", "cdecl"):
        continue
    yacLobCharSetId = _lib.get("yacLobCharSetId", "cdecl")
    yacLobCharSetId.argtypes = [YacHandle, POINTER(YacLobLocator), POINTER(YacUint8)]
    yacLobCharSetId.restype = YacResult
    break

# yacli.h: 309
for _lib in _libs.values():
    if not _lib.has("yacLobIsEqual", "cdecl"):
        continue
    yacLobIsEqual = _lib.get("yacLobIsEqual", "cdecl")
    yacLobIsEqual.argtypes = [
        YacHandle,
        POINTER(YacLobLocator),
        POINTER(YacLobLocator),
        POINTER(YacBool),
    ]
    yacLobIsEqual.restype = YacResult
    break

# yacli.h: 310
for _lib in _libs.values():
    if not _lib.has("yacLobIsTemporary", "cdecl"):
        continue
    yacLobIsTemporary = _lib.get("yacLobIsTemporary", "cdecl")
    yacLobIsTemporary.argtypes = [YacHandle, POINTER(YacLobLocator), POINTER(YacBool)]
    yacLobIsTemporary.restype = YacResult
    break

# yacli.h: 312
for _lib in _libs.values():
    if not _lib.has("yacLobCreateTemporary2", "cdecl"):
        continue
    yacLobCreateTemporary2 = _lib.get("yacLobCreateTemporary2", "cdecl")
    yacLobCreateTemporary2.argtypes = [
        YacHandle,
        POINTER(YacLobLocator),
        YacTempLobType,
    ]
    yacLobCreateTemporary2.restype = YacResult
    break

# yacli.h: 313
for _lib in _libs.values():
    if not _lib.has("yacLobRead2", "cdecl"):
        continue
    yacLobRead2 = _lib.get("yacLobRead2", "cdecl")
    yacLobRead2.argtypes = [
        YacHandle,
        POINTER(YacLobLocator),
        POINTER(YacUint64),
        POINTER(YacUint64),
        YacUint64,
        POINTER(YacUint8),
        YacUint64,
    ]
    yacLobRead2.restype = YacResult
    break

# yacli.h: 317
for _lib in _libs.values():
    if not _lib.has("yacDateGetDate", "cdecl"):
        continue
    yacDateGetDate = _lib.get("yacDateGetDate", "cdecl")
    yacDateGetDate.argtypes = [
        YacDate,
        POINTER(YacInt16),
        POINTER(YacUint8),
        POINTER(YacUint8),
    ]
    yacDateGetDate.restype = YacResult
    break

# yacli.h: 318
for _lib in _libs.values():
    if not _lib.has("yacDateSetDate", "cdecl"):
        continue
    yacDateSetDate = _lib.get("yacDateSetDate", "cdecl")
    yacDateSetDate.argtypes = [POINTER(YacDate), YacInt16, YacUint8, YacUint8]
    yacDateSetDate.restype = YacResult
    break

# yacli.h: 320
for _lib in _libs.values():
    if not _lib.has("yacShortTimeGetShortTime", "cdecl"):
        continue
    yacShortTimeGetShortTime = _lib.get("yacShortTimeGetShortTime", "cdecl")
    yacShortTimeGetShortTime.argtypes = [
        YacShortTime,
        POINTER(YacUint8),
        POINTER(YacUint8),
        POINTER(YacUint8),
        POINTER(YacUint32),
    ]
    yacShortTimeGetShortTime.restype = YacResult
    break

# yacli.h: 321
for _lib in _libs.values():
    if not _lib.has("yacShortTimeSetShortTime", "cdecl"):
        continue
    yacShortTimeSetShortTime = _lib.get("yacShortTimeSetShortTime", "cdecl")
    yacShortTimeSetShortTime.argtypes = [
        POINTER(YacShortTime),
        YacUint8,
        YacUint8,
        YacUint8,
        YacUint32,
    ]
    yacShortTimeSetShortTime.restype = YacResult
    break

# yacli.h: 323
for _lib in _libs.values():
    if not _lib.has("yacTimestampGetTimestamp", "cdecl"):
        continue
    yacTimestampGetTimestamp = _lib.get("yacTimestampGetTimestamp", "cdecl")
    yacTimestampGetTimestamp.argtypes = [
        YacTimestamp,
        POINTER(YacInt16),
        POINTER(YacUint8),
        POINTER(YacUint8),
        POINTER(YacUint8),
        POINTER(YacUint8),
        POINTER(YacUint8),
        POINTER(YacUint32),
    ]
    yacTimestampGetTimestamp.restype = YacResult
    break

# yacli.h: 324
for _lib in _libs.values():
    if not _lib.has("yacTimestampSetTimestamp", "cdecl"):
        continue
    yacTimestampSetTimestamp = _lib.get("yacTimestampSetTimestamp", "cdecl")
    yacTimestampSetTimestamp.argtypes = [
        POINTER(YacTimestamp),
        YacInt16,
        YacUint8,
        YacUint8,
        YacUint8,
        YacUint8,
        YacUint8,
        YacUint32,
    ]
    yacTimestampSetTimestamp.restype = YacResult
    break

# yacli.h: 326
for _lib in _libs.values():
    if not _lib.has("yacYMIntervalGetYearMonth", "cdecl"):
        continue
    yacYMIntervalGetYearMonth = _lib.get("yacYMIntervalGetYearMonth", "cdecl")
    yacYMIntervalGetYearMonth.argtypes = [
        YacYMInterval,
        POINTER(YacInt32),
        POINTER(YacInt32),
    ]
    yacYMIntervalGetYearMonth.restype = YacResult
    break

# yacli.h: 327
for _lib in _libs.values():
    if not _lib.has("yacYMIntervalSetYearMonth", "cdecl"):
        continue
    yacYMIntervalSetYearMonth = _lib.get("yacYMIntervalSetYearMonth", "cdecl")
    yacYMIntervalSetYearMonth.argtypes = [POINTER(YacYMInterval), YacInt32, YacInt32]
    yacYMIntervalSetYearMonth.restype = YacResult
    break

# yacli.h: 329
for _lib in _libs.values():
    if not _lib.has("yacDSIntervalGetDaySecond", "cdecl"):
        continue
    yacDSIntervalGetDaySecond = _lib.get("yacDSIntervalGetDaySecond", "cdecl")
    yacDSIntervalGetDaySecond.argtypes = [
        YacDSInterval,
        POINTER(YacInt32),
        POINTER(YacInt32),
        POINTER(YacInt32),
        POINTER(YacInt32),
        POINTER(YacInt32),
    ]
    yacDSIntervalGetDaySecond.restype = YacResult
    break

# yacli.h: 330
for _lib in _libs.values():
    if not _lib.has("yacDSIntervalSetDaySecond", "cdecl"):
        continue
    yacDSIntervalSetDaySecond = _lib.get("yacDSIntervalSetDaySecond", "cdecl")
    yacDSIntervalSetDaySecond.argtypes = [
        POINTER(YacDSInterval),
        YacInt32,
        YacInt32,
        YacInt32,
        YacInt32,
        YacInt32,
    ]
    yacDSIntervalSetDaySecond.restype = YacResult
    break

# yacli.h: 332
for _lib in _libs.values():
    if not _lib.has("yacDSIntervalFromText", "cdecl"):
        continue
    yacDSIntervalFromText = _lib.get("yacDSIntervalFromText", "cdecl")
    yacDSIntervalFromText.argtypes = [
        YacHandle,
        POINTER(YacDSInterval),
        POINTER(YacChar),
        YacUint32,
    ]
    yacDSIntervalFromText.restype = YacResult
    break

# yacli.h: 334
for _lib in _libs.values():
    if not _lib.has("yacRowIdToText", "cdecl"):
        continue
    yacRowIdToText = _lib.get("yacRowIdToText", "cdecl")
    yacRowIdToText.argtypes = [
        POINTER(YacRowId),
        POINTER(YacChar),
        YacInt32,
        POINTER(YacInt32),
    ]
    yacRowIdToText.restype = YacResult
    break

# yacli.h: 335
for _lib in _libs.values():
    if not _lib.has("yacTextToRowId", "cdecl"):
        continue
    yacTextToRowId = _lib.get("yacTextToRowId", "cdecl")
    yacTextToRowId.argtypes = [POINTER(YacChar), YacInt32, POINTER(YacRowId)]
    yacTextToRowId.restype = YacResult
    break

# yacli.h: 337
for _lib in _libs.values():
    if not _lib.has("yacNumberRound", "cdecl"):
        continue
    yacNumberRound = _lib.get("yacNumberRound", "cdecl")
    yacNumberRound.argtypes = [POINTER(YacNumber), YacInt32, YacInt32]
    yacNumberRound.restype = YacResult
    break

# yacli.h: 338
for _lib in _libs.values():
    if not _lib.has("yacNumberFromInt", "cdecl"):
        continue
    yacNumberFromInt = _lib.get("yacNumberFromInt", "cdecl")
    yacNumberFromInt.argtypes = [YacPointer, YacUint32, YacUint32, POINTER(YacNumber)]
    yacNumberFromInt.restype = YacResult
    break

YepMethod = CFUNCTYPE(UNCHECKED(YacResult), YacHandle)  # yacli.h: 342

# yacli.h: 344
for _lib in _libs.values():
    if not _lib.has("yepGetInt8", "cdecl"):
        continue
    yepGetInt8 = _lib.get("yepGetInt8", "cdecl")
    yepGetInt8.argtypes = [YacHandle, YacInt32, POINTER(YacInt8), POINTER(YacInt32)]
    yepGetInt8.restype = YacResult
    break

# yacli.h: 345
for _lib in _libs.values():
    if not _lib.has("yepGetInt16", "cdecl"):
        continue
    yepGetInt16 = _lib.get("yepGetInt16", "cdecl")
    yepGetInt16.argtypes = [YacHandle, YacInt32, POINTER(YacInt16), POINTER(YacInt32)]
    yepGetInt16.restype = YacResult
    break

# yacli.h: 346
for _lib in _libs.values():
    if not _lib.has("yepGetInt32", "cdecl"):
        continue
    yepGetInt32 = _lib.get("yepGetInt32", "cdecl")
    yepGetInt32.argtypes = [YacHandle, YacInt32, POINTER(YacInt32), POINTER(YacInt32)]
    yepGetInt32.restype = YacResult
    break

# yacli.h: 347
for _lib in _libs.values():
    if not _lib.has("yepGetInt64", "cdecl"):
        continue
    yepGetInt64 = _lib.get("yepGetInt64", "cdecl")
    yepGetInt64.argtypes = [YacHandle, YacInt32, POINTER(YacInt64), POINTER(YacInt32)]
    yepGetInt64.restype = YacResult
    break

# yacli.h: 348
for _lib in _libs.values():
    if not _lib.has("yepGetDate", "cdecl"):
        continue
    yepGetDate = _lib.get("yepGetDate", "cdecl")
    yepGetDate.argtypes = [YacHandle, YacInt32, POINTER(YacDate), POINTER(YacInt32)]
    yepGetDate.restype = YacResult
    break

# yacli.h: 349
for _lib in _libs.values():
    if not _lib.has("yepGetFloat", "cdecl"):
        continue
    yepGetFloat = _lib.get("yepGetFloat", "cdecl")
    yepGetFloat.argtypes = [YacHandle, YacInt32, POINTER(YacFloat), POINTER(YacInt32)]
    yepGetFloat.restype = YacResult
    break

# yacli.h: 350
for _lib in _libs.values():
    if not _lib.has("yepGetDouble", "cdecl"):
        continue
    yepGetDouble = _lib.get("yepGetDouble", "cdecl")
    yepGetDouble.argtypes = [YacHandle, YacInt32, POINTER(YacDouble), POINTER(YacInt32)]
    yepGetDouble.restype = YacResult
    break

# yacli.h: 351
for _lib in _libs.values():
    if not _lib.has("yepGetNumber", "cdecl"):
        continue
    yepGetNumber = _lib.get("yepGetNumber", "cdecl")
    yepGetNumber.argtypes = [YacHandle, YacInt32, POINTER(YacNumber), POINTER(YacInt32)]
    yepGetNumber.restype = YacResult
    break

# yacli.h: 352
for _lib in _libs.values():
    if not _lib.has("yepGetString", "cdecl"):
        continue
    yepGetString = _lib.get("yepGetString", "cdecl")
    yepGetString.argtypes = [
        YacHandle,
        YacInt32,
        POINTER(YacChar),
        YacUint32,
        POINTER(YacInt32),
    ]
    yepGetString.restype = YacResult
    break

# yacli.h: 353
for _lib in _libs.values():
    if not _lib.has("yepGetBytes", "cdecl"):
        continue
    yepGetBytes = _lib.get("yepGetBytes", "cdecl")
    yepGetBytes.argtypes = [
        YacHandle,
        YacInt32,
        POINTER(YacUint8),
        YacUint32,
        POINTER(YacInt32),
    ]
    yepGetBytes.restype = YacResult
    break

# yacli.h: 355
for _lib in _libs.values():
    if not _lib.has("yepOutputNull", "cdecl"):
        continue
    yepOutputNull = _lib.get("yepOutputNull", "cdecl")
    yepOutputNull.argtypes = [YacHandle, YacInt32]
    yepOutputNull.restype = YacResult
    break

# yacli.h: 356
for _lib in _libs.values():
    if not _lib.has("yepOutputInt8", "cdecl"):
        continue
    yepOutputInt8 = _lib.get("yepOutputInt8", "cdecl")
    yepOutputInt8.argtypes = [YacHandle, YacInt32, YacInt8]
    yepOutputInt8.restype = YacResult
    break

# yacli.h: 357
for _lib in _libs.values():
    if not _lib.has("yepOutputInt16", "cdecl"):
        continue
    yepOutputInt16 = _lib.get("yepOutputInt16", "cdecl")
    yepOutputInt16.argtypes = [YacHandle, YacInt32, YacInt16]
    yepOutputInt16.restype = YacResult
    break

# yacli.h: 358
for _lib in _libs.values():
    if not _lib.has("yepOutputInt32", "cdecl"):
        continue
    yepOutputInt32 = _lib.get("yepOutputInt32", "cdecl")
    yepOutputInt32.argtypes = [YacHandle, YacInt32, YacInt32]
    yepOutputInt32.restype = YacResult
    break

# yacli.h: 359
for _lib in _libs.values():
    if not _lib.has("yepOutputInt64", "cdecl"):
        continue
    yepOutputInt64 = _lib.get("yepOutputInt64", "cdecl")
    yepOutputInt64.argtypes = [YacHandle, YacInt32, YacInt64]
    yepOutputInt64.restype = YacResult
    break

# yacli.h: 360
for _lib in _libs.values():
    if not _lib.has("yepOutputDate", "cdecl"):
        continue
    yepOutputDate = _lib.get("yepOutputDate", "cdecl")
    yepOutputDate.argtypes = [YacHandle, YacInt32, YacDate]
    yepOutputDate.restype = YacResult
    break

# yacli.h: 361
for _lib in _libs.values():
    if not _lib.has("yepOutputFloat", "cdecl"):
        continue
    yepOutputFloat = _lib.get("yepOutputFloat", "cdecl")
    yepOutputFloat.argtypes = [YacHandle, YacInt32, YacFloat]
    yepOutputFloat.restype = YacResult
    break

# yacli.h: 362
for _lib in _libs.values():
    if not _lib.has("yepOutputDouble", "cdecl"):
        continue
    yepOutputDouble = _lib.get("yepOutputDouble", "cdecl")
    yepOutputDouble.argtypes = [YacHandle, YacInt32, YacDouble]
    yepOutputDouble.restype = YacResult
    break

# yacli.h: 363
for _lib in _libs.values():
    if not _lib.has("yepOutputNumber", "cdecl"):
        continue
    yepOutputNumber = _lib.get("yepOutputNumber", "cdecl")
    yepOutputNumber.argtypes = [YacHandle, YacInt32, POINTER(YacNumber)]
    yepOutputNumber.restype = YacResult
    break

# yacli.h: 364
for _lib in _libs.values():
    if not _lib.has("yepOutputString", "cdecl"):
        continue
    yepOutputString = _lib.get("yepOutputString", "cdecl")
    yepOutputString.argtypes = [YacHandle, YacInt32, POINTER(YacChar)]
    yepOutputString.restype = YacResult
    break

# yacli.h: 365
for _lib in _libs.values():
    if not _lib.has("yepOutputBytes", "cdecl"):
        continue
    yepOutputBytes = _lib.get("yepOutputBytes", "cdecl")
    yepOutputBytes.argtypes = [YacHandle, YacInt32, POINTER(YacUint8), YacUint32]
    yepOutputBytes.restype = YacResult
    break

# /opt/rh/devtoolset-7/root/usr/lib/gcc/x86_64-redhat-linux/7/include/stdbool.h: 34
try:
    true = 1
except:
    pass

# /opt/rh/devtoolset-7/root/usr/lib/gcc/x86_64-redhat-linux/7/include/stdbool.h: 35
try:
    false = 0
except:
    pass

# yacli.h: 14
try:
    YAC_TRUE = true
except:
    pass

# yacli.h: 15
try:
    YAC_FALSE = false
except:
    pass

# yacli.h: 18
try:
    YAC_MIN_PACKET_SIZE = 65536
except:
    pass

# yacli.h: 19
try:
    YAC_MAX_PACKET_SIZE = 33554432
except:
    pass

# yacli.h: 22
try:
    YAC_NULL_DATA = -1
except:
    pass

# yacli.h: 23
try:
    YAC_NULL_TERM_STR = -2
except:
    pass

# yacli.h: 25
try:
    YAC_LOB_INVALID_CHARSET_ID = -1
except:
    pass

# yacli.h: 27
try:
    YAC_NUMBER_UNSIGNED = 0
except:
    pass

# yacli.h: 28
try:
    YAC_NUMBER_SIGNED = 2
except:
    pass

# yacli.h: 50
try:
    YAC_NUMBER_SIZE = 20
except:
    pass

# yacli.h: 55
try:
    YAC_ROWID_SIZE = 16
except:
    pass

# yacli.h: 60
try:
    YAC_TIMESTAMP_SIZE = 12
except:
    pass

# yacli.h: 341
try:
    YEP_RETURN = (YacUint16(ord_if_char(65535))).value
except:
    pass


# yacli.h: 367
def yepReturnNull(hProc):
    return yepOutputNull(hProc, YEP_RETURN)


# yacli.h: 368
def yepReturnInt8(hProc, value):
    return yepOutputInt8(hProc, YEP_RETURN, value)


# yacli.h: 369
def yepReturnInt16(hProc, value):
    return yepOutputInt16(hProc, YEP_RETURN, value)


# yacli.h: 370
def yepReturnInt32(hProc, value):
    return yepOutputInt32(hProc, YEP_RETURN, value)


# yacli.h: 371
def yepReturnInt64(hProc, value):
    return yepOutputInt64(hProc, YEP_RETURN, value)


# yacli.h: 372
def yepReturnFloat(hProc, value):
    return yepOutputFloat(hProc, YEP_RETURN, value)


# yacli.h: 373
def yepReturnDouble(hProc, value):
    return yepOutputDouble(hProc, YEP_RETURN, value)


# yacli.h: 374
def yepReturnDate(hProc, value):
    return yepOutputDate(hProc, YEP_RETURN, value)


# yacli.h: 375
def yepReturnNumber(hProc, value):
    return yepOutputNumber(hProc, YEP_RETURN, value)


# yacli.h: 376
def yepReturnString(hProc, value):
    return yepOutputString(hProc, YEP_RETURN, value)


# yacli.h: 377
def yepReturnBytes(hProc, value, size):
    return yepOutputBytes(hProc, YEP_RETURN, value, size)


StYacNumber = struct_StYacNumber  # yacli.h: 53

StYacRowId = struct_StYacRowId  # yacli.h: 58

StYacTimestamp = struct_StYacTimestamp  # yacli.h: 63

StYacTextPos = struct_StYacTextPos  # yacli.h: 76

# No inserted files

# No prefix-stripping
