from ctypes import POINTER
from typing import Any
from yasdb.libs import yacli, exceptions
from yasdb.commons import YasdbState, YacUtil
from yasdb.cursor import YasdbCursor


class YasdbConnection:
    def __init__(self) -> None:

        self._env: yacli.YacHandle = None
        self._conn: yacli.YacHandle = None
        self.state = YasdbState.INIT
        self._connected = False
        self._autocommit = False
        self.user = ""
        self.dsn = ""
        self.maxRatio: int = 1
        self.maxNRatio: int = 1
        self.lobs = []

    def __del__(self):
        if self._connected:
            self.close()

    def __enter__(self):
        self._verify_connected()
        return self

    def __exit__(self, exc_type, exc_value, exc_tb):
        self.close()

    @property
    def autocommit(self):
        return self._autocommit

    @autocommit.setter
    def autocommit(self, ac):
        self._autocommit = ac
        self.set_auto_commit()

    def __repr__(self) -> str:
        return "yasdb.Connection to {}@{}".format(self.user, self.dsn)

    @property
    def handler(self) -> yacli.YacHandle:
        return self._conn

    def _free_env(self):
        if not self._env:
            return
        yacli.yacFreeHandle(yacli.YAC_HANDLE_ENV, self._env)
        self._env = None

    def _free_conn(self):
        if not self._conn:
            return
        yacli.yacFreeHandle(yacli.YAC_HANDLE_DBC, self._conn)
        self._conn = None

    def _alloc_env(self):
        self._env = yacli.YacHandle()
        _env_ptr = POINTER(yacli.YacHandle)
        ret = yacli.yacAllocHandle(
            yacli.YAC_HANDLE_ENV, yacli.YacHandle(), _env_ptr(self._env)
        )
        yacli.yacSetEnvAttr(self._env, yacli.YAC_ATTR_CLIENT_DRIVER, YacUtil.alloc_yac_char("YashanDB Python Driver"), 22)
        YacUtil.assert_ret(ret)

    def _alloc_conn(self):
        self._conn = yacli.YacHandle()
        _conn_ptr = POINTER(yacli.YacHandle)
        ret = yacli.yacAllocHandle(
            yacli.YAC_HANDLE_DBC, self._env, _conn_ptr(self._conn)
        )
        YacUtil.assert_ret(ret)

    def _get_conn_int_attr(self, t: yacli.YacConnAttr) -> int:
        indicator_ptr = YacUtil.alloc_yac_int32()
        _value_ptr = YacUtil.alloc_yac_int32()
        ret = yacli.yacGetConnAttr(
            self.handler,
            t,
            _value_ptr,
            4,
            indicator_ptr,
        )
        YacUtil.assert_ret(ret)
        return YacUtil.pointer_value(_value_ptr)

    def _verify_connected(self) -> None:
        """
        Verifies that the connection is connected to the database. If it is
        not, an exception is raised.
        """
        if not self._connected:
            raise exceptions.InterfaceError("not connected")

    def connect(self, dsn: str, username: str, password: str, autocommit: bool):
        self._autocommit = autocommit
        self._alloc_env()
        self._alloc_conn()
        self._connected = True
        _dsn_ptr = YacUtil.alloc_yac_char(dsn)
        _username_ptr = YacUtil.alloc_yac_char(username)
        _password_ptr = YacUtil.alloc_yac_char(password)

        ret = yacli.yacConnect(
            self._conn,
            _dsn_ptr,
            YacUtil.ptr_value_size(_dsn_ptr),
            _username_ptr,
            YacUtil.ptr_value_size(_username_ptr),
            _password_ptr,
            YacUtil.ptr_value_size(_password_ptr),
        )
        YacUtil.assert_ret(ret)
        self.user = username
        self.dsn = dsn
        self.state = YasdbState.OPEN
        self.set_env_charset()
        self.set_auto_commit()
        self.maxRatio = self._get_conn_int_attr(yacli.YAC_ATTR_MAX_CHARSET_RATIO)
        self.maxNRatio = self._get_conn_int_attr(yacli.YAC_ATTR_MAX_NCHARSET_RATIO)

    def disconnect(self):
        if not self._connected:
            return
        yacli.yacDisconnect(self._conn)

    def set_auto_commit(self):
        auto_ptr = YacUtil.alloc_yac_int32(1 if self._autocommit else 0)
        ret = yacli.yacSetConnAttr(self._conn, yacli.YAC_ATTR_AUTOCOMMIT, auto_ptr, 4)
        YacUtil.assert_ret(ret)

    def set_env_charset(self):
        charset_ptr = YacUtil.alloc_yac_int32(yacli.YAC_CHARSET_UTF8)
        ret = yacli.yacSetEnvAttr(
            self._env, yacli.YAC_ATTR_CHARSET_CODE, charset_ptr, 4
        )
        YacUtil.assert_ret(ret)

    def _free_lob(self):
        while self.lobs:
            lob = self.lobs.pop()
            lob.free()

    def close(self):
        self._free_lob()
        self.disconnect()
        self._free_conn()
        self._free_env()
        self.state = YasdbState.CLOSED
        self._verify_connected()
        self._connected = False

    def commit(self):
        YacUtil.assert_ret(yacli.yacCommit(self._conn))

    def rollback(self):
        YacUtil.assert_ret(yacli.yacRollback(self._conn))

    def cursor(self) -> YasdbCursor:
        return YasdbCursor(self)


def replace_special_chars(dsn_str):
    special_chars = {
        "\\": "{dsn_placeholder_1}",
        "/": "{dsn_placeholder_2}",
        "@": "{dsn_placeholder_3}",
    }
    escape_char = "\\"
    for k, v in special_chars.items():
        dsn_str = dsn_str.replace(escape_char + k, v)
    return dsn_str


def recovery_special_chars(s):
    special_chars = {
        "\\": "{dsn_placeholder_1}",
        "/": "{dsn_placeholder_2}",
        "@": "{dsn_placeholder_3}",
    }
    for v, k in special_chars.items():
        s = s.replace(k, v)
    return s


def connect(
    dsn: str = None,
    user: str = None,
    password: str = None,
    *,
    host: str = None,
    port: int = 1688,
    autocommit: bool = False,
) -> YasdbConnection:
    conn = YasdbConnection()
    if dsn and "@" in dsn:
        dsn_str = replace_special_chars(dsn)
        dsn_str_parts = dsn_str.split("@")
        dsn_str = dsn_str_parts[1] if len(dsn_str_parts) > 1 else None
        user_pass = dsn_str_parts[0]
        if "/" in user_pass:
            user_pass = user_pass.split("/")
            user_str = user_pass[0]
            pass_str = user_pass[1] if len(user_pass) > 1 else None
            password = recovery_special_chars(pass_str)
        else:
            user_str = user_pass
        user = recovery_special_chars(user_str)
        dsn = dsn_str
    if not dsn:
        dsn = host + ":" + str(port)
    try:
        conn.connect(dsn, user, password, autocommit=autocommit)
    except:
        conn.close()
        raise
    return conn
