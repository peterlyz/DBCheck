import os


def get_env(name, default=None, is_bool=False):
    def inner():
        value = os.environ.get(name)
        if value is not None:
            if is_bool:
                return value.lower() == "true"
            else:
                return value
        return default

    return inner


ENABLE_FAILED_SQL_LOG = get_env("PY_YASDB_ENABLE_FAILED_SQL_LOG", False, True)
