import logging

from ctypes import POINTER
from yasdb.settings import ENABLE_FAILED_SQL_LOG
from typing import Callable, Any, Union
from yasdb.libs import yacli, exceptions
from yasdb.rows import YasColumn, YasParameter
from yasdb.commons import YacUtil, YasdbState, HIGHLIGHT_OUTPUT_PREFIX, HIGHLIGHT_OUTPUT_SUFFIX

logger = logging.getLogger('cursor')

class YasdbCursor:
    def __init__(self, conn):

        self.conn = conn
        self._stmt: yacli.YacHandle = None
        self._columns: list[YasColumn] = None
        self._rowcount = 0
        self._state = YasdbState.INIT
        self._prepared = False

        self._parameters: list[YasParameter] = None
        self.arraysize = 100
        self.statement = ''

    def __enter__(self):
        self._verify_open()
        return self

    def __exit__(self, exc_type, exc_value, exc_tb):
        self._verify_open()
        self.close()

    @property
    def rowcount(self) -> int:
        return self._rowcount

    @property
    def handler(self) -> yacli.YacHandle:
        return self._stmt

    @property
    def description(self):
        if self._columns is None:
            return None
        return [x.to_sequence() for x in self._columns]

    def _verify_open(self) -> None:
        """
        Verifies that the cursor is open and the associated connection is
        connected. If either condition is false an exception is raised.
        """
        if self._state == YasdbState.INIT or self._state == YasdbState.OPEN:
            return
        raise exceptions.InterfaceError("not open")

    def _assert_open(self):
        if self._state == YasdbState.OPEN:
            return
        raise exceptions.InterfaceError("not open")

    def _assert_prepared(self):
        if self._prepared:
            return
        raise exceptions.InterfaceError("not a query")

    def __iter__(self):
        return iter(self.fetchone, None)

    def __next__(self):
        row = self.fetchone()
        if row is None:
            raise StopIteration
        return row

    def _alloc_stmt(self):
        self._stmt = yacli.YacHandle()
        _stmt_ptr = POINTER(yacli.YacHandle)
        ret = yacli.yacAllocHandle(
            yacli.YAC_HANDLE_STMT, self.conn.handler, _stmt_ptr(self._stmt)
        )
        YacUtil.assert_ret(ret)
        self._state = YasdbState.OPEN

    def _free_stmt(self):
        self._state = YasdbState.CLOSED
        if not self._stmt:
            return
        yacli.yacFreeHandle(yacli.YAC_HANDLE_STMT, self._stmt)
        self._stmt = None

    def _get_stmt_int_attr(self, t: yacli.YacStmtAttr) -> int:
        strlength_ptr = YacUtil.alloc_yac_int32()
        _value_ptr = YacUtil.alloc_yac_int32()
        ret = yacli.yacGetStmtAttr(
            self.handler,
            t,
            _value_ptr,
            4,
            strlength_ptr,
        )
        YacUtil.assert_ret(ret)
        return YacUtil.pointer_value(_value_ptr)

    def _get_row_affected(self) -> int:
        return self._get_stmt_int_attr(yacli.YAC_ATTR_ROWS_AFFECTED)

    def close(self) -> None:
        self._verify_open()
        self._free_stmt()

    def prepare(self, sql: str) -> None:
        self._verify_open()
        self._columns = None
        self._parameters = None
        self._rowcount = 0
        self._prepared = False
        if not self._stmt:
            self._alloc_stmt()

        _sql_ptr = YacUtil.alloc_yac_char(sql)
        ret = yacli.yacPrepare(self._stmt, _sql_ptr, YacUtil.ptr_value_size(_sql_ptr))
        if ENABLE_FAILED_SQL_LOG() and ret != yacli.YAC_SUCCESS:
            logger.error(
                "{prefix} FAILED PREPARE SQL: {sql} {suffix}".format(
                    prefix=HIGHLIGHT_OUTPUT_PREFIX, sql=sql, suffix=HIGHLIGHT_OUTPUT_SUFFIX
                )
            )
        YacUtil.assert_ret(ret)
        self._prepared = True
        self.statement = sql

    def execute(
        self,
        sql: Union[str, None],
        params: Union[list, tuple, dict] = None,
        **keyword_parameters: Any,
    ) -> Any:
        self.prepare(sql)
        self.bind_parameters(params, keyword_parameters)
        ret = yacli.yacExecute(self._stmt)
        if ENABLE_FAILED_SQL_LOG() and ret != yacli.YAC_SUCCESS:
            logger.error(
                "{prefix} FAILED EXECUTE SQL: {sql} {params} {suffix}".format(
                    prefix=HIGHLIGHT_OUTPUT_PREFIX, sql=sql, params=str(params), suffix=HIGHLIGHT_OUTPUT_SUFFIX
                )
            )
        YacUtil.assert_ret(ret)
        self.bind_columns()
        self._rowcount = self._get_row_affected()
        return self

    def executemany(self, sql: str, multi_params=None) -> None:
        if not multi_params:
            return self.execute(sql)
        self.prepare(sql)
        for params in multi_params:
            self.bind_parameters(params)  # 后续要改成批量多行绑定
            ret = yacli.yacExecute(self._stmt)
            if ENABLE_FAILED_SQL_LOG() and ret != yacli.YAC_SUCCESS:
                logger.error(
                    "{preifx} FAILED EXECUTE SQL: {sql} {params} {suffix}".format(
                        preifx=HIGHLIGHT_OUTPUT_PREFIX, sql=sql, params=str(params), suffix=HIGHLIGHT_OUTPUT_SUFFIX
                    )
                )
            YacUtil.assert_ret(ret)
        self._rowcount = self._get_row_affected()

    def fetchone(self) -> Any:
        if not self._fetch():
            return None
        values = []
        for row in self._columns:
            values.append(row.get_column_value())
        return tuple(values)

    def _fetch(self) -> int:
        self._assert_prepared()
        self._assert_open()
        if not self._columns:
            raise exceptions.InterfaceError("not a query")

        _rows = yacli.YacUint32()
        _rows_ptr = POINTER(yacli.YacUint32)
        ret = yacli.yacFetch(self._stmt, _rows_ptr(_rows))
        if ENABLE_FAILED_SQL_LOG() and ret != yacli.YAC_SUCCESS:
            logger.error(
                "{prefix} FETCH FAILED SQL: {sql} {suffix}".format(
                    prefix=HIGHLIGHT_OUTPUT_PREFIX, sql=self.statement, suffix=HIGHLIGHT_OUTPUT_SUFFIX
                )
            )
        YacUtil.assert_ret(ret)
        if _rows.value:
            self._rowcount += 1
            return True
        return False

    def _get_column_nums(self) -> int:
        num_ptr = YacUtil.alloc_yac_int16()
        YacUtil.assert_ret(yacli.yacNumResultCols(self._stmt, num_ptr))
        return YacUtil.pointer_value(num_ptr)

    def bind_columns(self):
        column_nums = self._get_column_nums()
        if column_nums == 0:
            return
        self._columns = []
        for index in range(column_nums):
            row = YasColumn(self, index=index)
            row.bind_column()
            self._columns.append(row)
        return

    def bind_parameters(self, params, keyword_parameters=None):
        if not params and not keyword_parameters:
            return
        if not params and keyword_parameters:
            params = keyword_parameters
        self._parameters = []
        if type(params) is dict:
            for k, v in params.items():
                row = None
                arg_name = k[1:] if k.startswith(':') else k
                if isinstance(v, YasParameter):
                    v._name = arg_name
                    row = v
                else:
                    row = YasParameter(self, name=arg_name)
                    row.setvalue(v, free_with_conn=True)
                row.bind_named_parameter()
                self._parameters.append(row)
            return
        for i, item in enumerate(params):
            row = None
            if isinstance(item, YasParameter):
                item.index = i
                row = item
            else:
                row = YasParameter(self, index=i)
                row.setvalue(item, free_with_conn=True)
            row.bind_index_parameter()
            self._parameters.append(row)
        return

    # 存储过程
    def callproc(self, procname, params=None) -> list:
        sb = []
        if params:
            sb = ["?" for v in params]
        sql = "begin {}({}); end;".format(procname, ",".join(sb))
        self.execute(sql, params=params)
        if params is None:
            return []
        return [v.getvalue() for v in self._parameters]

    def fetchall(self) -> list:
        data = []
        while True:
            row = self.fetchone()
            if not row:
                break
            data.append(row)
        return data

    def fetchmany(self, nums: int = None) -> list:
        data = []
        if nums is None:
            nums = self.arraysize
        fetchsize = nums if nums > 0 else 0
        for _ in range(fetchsize):
            row = self.fetchone()
            if not row:
                break
            data.append(row)
        return data

    def var(
        self,
        typ: any,
        size: int = -1,
        arraysize: int = 1,
        inconverter: Callable = None,
        outconverter: Callable = None,
    ) -> YasParameter:
        row = YasParameter(self)
        row.set_output(typ, size=size)
        return row
