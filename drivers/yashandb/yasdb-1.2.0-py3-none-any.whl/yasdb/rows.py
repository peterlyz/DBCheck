import sys
import time
import json
import datetime
from decimal import Decimal
from ctypes import POINTER

from yasdb.libs import yacli, exceptions
from yasdb.commons import YacUtil, MAX_VARCHAR_LENGTH
from yasdb.lob import LobValue
from yasdb import types
from yasdb.commons import MAX_VARCHAR_LENGTH, YacUtil
from yasdb.libs import exceptions, yacli

COLUMN_NAME_SIZE = 134  # 68 * 2
COLUMN_DESC_INDEXS = (
    "name",
    "type_code",
    "display_size",
    "internal_size",
    "precision",
    "scale",
    "null_ok",
)


class YasColumnDesc:
    __slots__ = (
        "name",
        "size",
        "typ",
        "precision",
        "scale",
        "nullable",
        "char_size",
        "char_used",
        "display_size",
        "display_char_size",
    )

    def __init__(self) -> None:
        self.name: str = ""  # 列名
        self.size: int = 0  # 列大小
        self.typ: int = 0  # 列类型
        self.precision: int = 0  # 列精度
        self.scale: int = 0  # 列范围
        self.nullable: int = 0  # 列是否可为NULL
        self.char_size: int = 0  # 列字符大小
        self.char_used: int = 0  # 类型定义是否为字符长定义
        self.display_size: int = 0  # 列显示大小
        self.display_char_size: int = 0  # 列显示字符大小

    def __repr__(self) -> str:
        return "('{}', {}, {}, {}, {}, {}, {})".format(
            self.name,
            self.typ,
            self.display_size,
            self.size,
            self.precision,
            self.scale,
            self.nullable,
        )


class YasRow:
    __slots__ = ("conn", "cursor", "index", "desc", "_indicator_ptr", "_dbobj", "_name")

    def __init__(self, cursor, index: int) -> None:
        self.conn = cursor.conn
        self.cursor = cursor
        self.index = index
        self.desc: YasColumnDesc = None

        self._indicator_ptr = YacUtil.alloc_yac_int32()
        self._dbobj = None

    @property
    def name(self):
        return self.desc.name if self.desc else None

    @property
    def null_ok(self):
        return bool(self.desc.nullable) if self.desc else None

    @property
    def type_code(self):
        return self.desc.typ if self.desc else None

    @property
    def display_size(self):
        return self.desc.display_size if self.desc else None

    @property
    def internal_size(self):
        return self.desc.size if self.desc else None

    @property
    def precision(self):
        return self.desc.precision if self.desc else None

    def __getitem__(self, index):
        return getattr(self, COLUMN_DESC_INDEXS[index], None)

    def to_sequence(self):
        return tuple(getattr(self, x, None) for x in COLUMN_DESC_INDEXS)

    @property
    def scale(self):
        return self.desc.scale if self.desc else None

    def __repr__(self) -> str:
        return str(self.desc)

    def _get_col_int_attr(self, t: yacli.YacColAttr) -> int:
        indicator_ptr = YacUtil.alloc_yac_int32()
        value_map = {
            yacli.YAC_COL_ATTR_DISPLAY_SIZE: YacUtil.alloc_yac_uint32(),
            yacli.YAC_COL_ATTR_SIZE: YacUtil.alloc_yac_uint32(),
            yacli.YAC_COL_ATTR_TYPE: YacUtil.alloc_yac_uint8(),
            yacli.YAC_COL_ATTR_PRECISION: YacUtil.alloc_yac_uint8(),
            yacli.YAC_COL_ATTR_SCALE: YacUtil.alloc_yac_int8(),
            yacli.YAC_COL_ATTR_NULLABLE: YacUtil.alloc_yac_uint8(),
            yacli.YAC_COL_ATTR_CHAR_SIZE: YacUtil.alloc_yac_uint32(),
            yacli.YAC_COL_ATTR_CHAR_USED: YacUtil.alloc_yac_uint8(),
            yacli.YAC_COL_ATTR_DISPLAY_CHAR_SIZE: YacUtil.alloc_yac_uint32(),
        }
        buf_len_map = {
            yacli.YAC_COL_ATTR_DISPLAY_SIZE: 4,
            yacli.YAC_COL_ATTR_SIZE: 4,
            yacli.YAC_COL_ATTR_TYPE: 1,
            yacli.YAC_COL_ATTR_PRECISION: 1,
            yacli.YAC_COL_ATTR_SCALE: 1,
            yacli.YAC_COL_ATTR_NULLABLE: 1,
            yacli.YAC_COL_ATTR_CHAR_SIZE: 4,
            yacli.YAC_COL_ATTR_CHAR_USED: 1,
            yacli.YAC_COL_ATTR_DISPLAY_CHAR_SIZE: 4,
        }
        _value_ptr = value_map.get(t, None)
        _bufLen = buf_len_map.get(t, None)
        ret = yacli.yacColAttribute(
            self.cursor.handler,
            yacli.YacUint16(self.index),
            t,
            _value_ptr,
            _bufLen,
            indicator_ptr,
        )
        YacUtil.assert_ret(ret)
        return YacUtil.pointer_value(_value_ptr)

    def _get_col_str_attr(self, t: yacli.YacColAttr, size: int) -> str:
        _value_size = yacli.YacInt32(size)
        _value_ptr = YacUtil.alloc_yac_char(_value_size.value)

        indicator_ptr = YacUtil.alloc_yac_int32()
        ret = yacli.yacColAttribute(
            self.cursor.handler,
            yacli.YacUint16(self.index),
            t,
            _value_ptr,
            _value_size,
            indicator_ptr,
        )
        YacUtil.assert_ret(ret)
        return YacUtil.pointer_value(_value_ptr)

    def get_column_desc(self) -> YasColumnDesc:
        desc = YasColumnDesc()
        desc.name = self._get_col_str_attr(yacli.YAC_COL_ATTR_NAME, COLUMN_NAME_SIZE)
        desc.size = self._get_col_int_attr(yacli.YAC_COL_ATTR_SIZE)
        desc.typ = self._get_col_int_attr(yacli.YAC_COL_ATTR_TYPE)
        desc.precision = (
            self._get_col_int_attr(yacli.YAC_COL_ATTR_PRECISION)
            if self._get_col_int_attr(yacli.YAC_COL_ATTR_PRECISION) != 255
            else None
        )
        desc.scale = (
            self._get_col_int_attr(yacli.YAC_COL_ATTR_SCALE)
            if self._get_col_int_attr(yacli.YAC_COL_ATTR_SCALE) != -128
            else None
        )
        desc.nullable = self._get_col_int_attr(yacli.YAC_COL_ATTR_NULLABLE)
        desc.char_size = self._get_col_int_attr(yacli.YAC_COL_ATTR_CHAR_SIZE)
        desc.char_used = self._get_col_int_attr(yacli.YAC_COL_ATTR_CHAR_USED)
        desc.display_size = self._get_col_int_attr(yacli.YAC_COL_ATTR_DISPLAY_SIZE)
        desc.display_char_size = self._get_col_int_attr(
            yacli.YAC_COL_ATTR_DISPLAY_CHAR_SIZE
        )
        self.desc = desc


class YasColumn(YasRow):
    def __init__(self, cursor, index: int) -> None:
        super().__init__(cursor, index)

    def bind_column(self):
        self.get_column_desc()

        t = self.desc.typ
        if t not in types.YAS_INDEXS:
            self._dbobj = types.VARCHAR()
            self._dbobj.set_value(size=YacUtil.align_size(self.desc.display_size))
        else:
            _type_class = types.YAS_INDEXS[t]
            self._dbobj: types.YasType = _type_class()
            if self._dbobj.is_lob():
                self._dbobj.set_value(
                    value=None, conn=self.conn, is_tmp=True, free_with_conn=True
                )
            elif self._dbobj.is_char():
                self._dbobj.set_value(
                    value=None,
                    size=self._dbobj.get_desc_size(self.desc, self.conn.maxRatio),
                )
            elif self._dbobj.is_nchar():
                self._dbobj.set_value(
                    value=None,
                    size=self._dbobj.get_desc_size(self.desc, self.conn.maxNRatio),
                )
            else:
                self._dbobj.set_value(
                    value=None, size=self._dbobj.get_desc_size(self.desc)
                )

        ret = yacli.yacBindColumn(
            self.cursor.handler,
            self.index,
            self._dbobj.bind_type,
            self._dbobj.bind_ptr,
            self._dbobj.bind_size,
            self._indicator_ptr,
        )
        YacUtil.assert_ret(ret)

    def get_column_value(self):
        if YacUtil.pointer_value(self._indicator_ptr) == yacli.YAC_NULL_DATA:
            return None
        if isinstance(self._dbobj, (types.BINARY, types.BIT)):
            get_value = self._dbobj.get_value(
                YacUtil.pointer_value(self._indicator_ptr)
            )
        else:
            get_value = self._dbobj.get_value()
        if get_value == b"":
            return None
        return get_value


class YasParameter(YasRow):
    def __init__(
        self,
        cursor,
        index: int = -1,
        name: str = None,
    ) -> None:
        super().__init__(cursor, index)
        self._name = name

    @property
    def typ(self):
        if self._dbobj is None:
            return None
        return self._dbobj.typ

    @property
    def values(self):
        return [self.getvalue()]

    def getvalue(self):
        if self._dbobj is None:
            return None
        if isinstance(self._dbobj, (types.BINARY, types.BIT)):
            return self._dbobj.get_value(YacUtil.pointer_value(self._indicator_ptr))
        return self._dbobj.get_value()

    def free(self):
        if self._dbobj.is_lob():
            self._dbobj.free()

    def setvalue(self, value: any, free_with_conn=False):
        if value == b"":
            value = None
        if self._dbobj is not None:
            pass
        elif isinstance(value, str) and len(value) > MAX_VARCHAR_LENGTH:
            self._dbobj = types.CLOB()
        elif type(value) in types.TYPE_TO_YAS:
            # raise exceptions.NotSupportedError("unsupport type: {}".format(type(value)))
            yas_class = types.TYPE_TO_YAS[type(value)]
            if yas_class == types.BIGINT and YacUtil.is_overflow(value):
                yas_class = types.NUMBER
                value = str(value)
            self._dbobj: types.YasType = yas_class()
        elif isinstance(value, datetime.datetime):
            self._dbobj: types.YasType = types.DATETIME()
        else:
            self._dbobj = types.VARCHAR(value)
        if self._dbobj.is_lob():
            self._dbobj.set_value(
                value=value, conn=self.conn, is_tmp=True, free_with_conn=free_with_conn
            )
        else:
            self._dbobj.set_value(value=value)
        self.param_type: yacli.YacParamDirection = yacli.YAC_PARAM_INPUT
        return self

    def set_output(self, typ: any, size: int = -1):
        _type_class = typ
        if typ in types.TYPE_TO_YAS:
            _type_class = types.TYPE_TO_YAS[typ]

        if not issubclass(_type_class, types.YasType):
            raise exceptions.NotSupportedError("unsupport type: {}".format(str(typ)))
        self.param_type = yacli.YAC_PARAM_OUTPUT
        bind_size = _type_class.default_size if size < 0 else size
        self._dbobj = _type_class()
        self._dbobj._bind_size = bind_size
        return self

    def bind_index_parameter(self):

        if self.param_type == yacli.YAC_PARAM_OUTPUT and not self._dbobj.bind_ptr:
            if self._dbobj.is_lob():
                self._dbobj.set_value(
                    value=None, conn=self.conn, is_tmp=True, free_with_conn=True
                )
            else:
                if self._dbobj.bind_size < 0:
                    raise exceptions.OperationalError(
                        "param index:{} size must be given".format(self.index)
                    )
                self._dbobj.set_value(size=self._dbobj.bind_size)

        self._indicator_ptr = YacUtil.alloc_yac_int32(
            YacUtil.ptr_value_size(self._dbobj.bind_ptr)
        )
        ret = yacli.yacBindParameter(
            self.cursor.handler,
            self.index + 1,
            self.param_type,
            self._dbobj.bind_type,
            self._dbobj.bind_ptr,
            self._dbobj.bind_size,
            self._dbobj.bind_size,
            self._indicator_ptr,
        )
        YacUtil.assert_ret(ret)
        return

    def bind_named_parameter(self):
        if self._name is None:
            raise exceptions.InternalError("bind named parameter error: param name: {}".format(self._name))
        if self.param_type == yacli.YAC_PARAM_OUTPUT and not self._dbobj.bind_ptr:
            if self._dbobj.is_lob():
                self._dbobj.set_value(
                    value=None, conn=self.conn, is_tmp=True, free_with_conn=True
                )
            else:
                if self._dbobj.bind_size < 0:
                    raise exceptions.OperationalError(
                        "param name:{} size must be given".format(self._name)
                    )
                self._dbobj.set_value(size=self._dbobj.bind_size)

        self._indicator_ptr = YacUtil.alloc_yac_int32(
            YacUtil.ptr_value_size(self._dbobj.bind_ptr)
        )
        _name_ptr = YacUtil.alloc_yac_char(self._name)
        ret = yacli.yacBindParameterByName(
            self.cursor.handler,
            _name_ptr,
            self.param_type,
            self._dbobj.bind_type,
            self._dbobj.bind_ptr,
            self._dbobj.bind_size,
            self._dbobj.bind_size,
            self._indicator_ptr,
        )
        YacUtil.assert_ret(ret)
        return

    def __repr__(self) -> str:
        if self._dbobj:
            return "{}({})".format(self._dbobj.typename, self.getvalue())
        return "YasParameter({})".format(self.getvalue())
